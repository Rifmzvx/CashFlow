import 'package:catatkeuanganku/logic/balance.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('saldo dompet', () {
    test('saldo = saldo awal + pemasukan - pengeluaran', () {
      final trxs = [
        const TrxLite(type: TrxType.income, amount: 100000, walletId: 1),
        const TrxLite(type: TrxType.expense, amount: 30000, walletId: 1),
      ];
      expect(
        walletBalance(walletId: 1, initialBalance: 50000, trxs: trxs),
        120000,
      );
    });

    test('transfer: dua saldo berubah, saldo total tetap', () {
      final trxs = [
        const TrxLite(
            type: TrxType.transfer, amount: 10000, walletId: 1, toWalletId: 2),
      ];
      final bank = walletBalance(walletId: 1, initialBalance: 100000, trxs: trxs);
      final tunai = walletBalance(walletId: 2, initialBalance: 20000, trxs: trxs);
      expect(bank, 90000);
      expect(tunai, 30000);
      expect(bank + tunai, 120000); // total sebelum = sesudah
    });

    test('penyesuaian boleh negatif', () {
      final trxs = [
        const TrxLite(type: TrxType.adjustment, amount: -2500, walletId: 1),
      ];
      expect(walletBalance(walletId: 1, initialBalance: 10000, trxs: trxs), 7500);
    });

    test('setor tabungan mengurangi dompet, tarik menambah', () {
      final trxs = [
        const TrxLite(
            type: TrxType.savingIn, amount: 20000, walletId: 1, savingsId: 9),
        const TrxLite(
            type: TrxType.savingOut, amount: 5000, walletId: 1, savingsId: 9),
      ];
      expect(walletBalance(walletId: 1, initialBalance: 50000, trxs: trxs), 35000);
      expect(savingsBalance(9, trxs), 15000);
      expect(savingsBalance(8, trxs), 0);
    });
  });

  group('validasi', () {
    test('nominal harus > 0', () {
      expect(
          validateTrx(type: TrxType.expense, amount: 0, walletId: 1), isNotNull);
      expect(validateTrx(type: TrxType.expense, amount: 1000, walletId: 1), isNull);
    });
    test('transfer ke dompet yang sama ditolak', () {
      expect(
        validateTrx(
            type: TrxType.transfer, amount: 1000, walletId: 1, toWalletId: 1),
        isNotNull,
      );
      expect(
        validateTrx(
            type: TrxType.transfer, amount: 1000, walletId: 1, toWalletId: 2),
        isNull,
      );
    });
    test('penyesuaian nol ditolak', () {
      expect(
          validateTrx(type: TrxType.adjustment, amount: 0, walletId: 1), isNotNull);
    });
    test('tabungan wajib dipilih', () {
      expect(validateTrx(type: TrxType.savingIn, amount: 1000, walletId: 1),
          isNotNull);
    });
  });

  group('nomor transaksi', () {
    test('mulai dari 0001', () {
      expect(nextTrxNumber(2026, null), 'TRX-2026-0001');
    });
    test('berlanjut dalam tahun yang sama', () {
      expect(nextTrxNumber(2026, 'TRX-2026-0009'), 'TRX-2026-0010');
    });
    test('reset saat tahun baru', () {
      expect(nextTrxNumber(2027, 'TRX-2026-0150'), 'TRX-2027-0001');
    });
  });

  group('target tabungan', () {
    final now = DateTime.utc(2026, 10, 18);
    test('estimasi dari rata-rata 30 hari', () {
      // sisa 70.000, setoran bersih 30.000/30 hari = 1.000/hari -> 70 hari
      final d = estimateGoalDate(
          target: 100000, current: 30000, netLast30Days: 30000, now: now);
      expect(d, now.add(const Duration(days: 70)));
    });
    test('tanpa setoran -> null', () {
      expect(
        estimateGoalDate(
            target: 100000, current: 0, netLast30Days: 0, now: now),
        isNull,
      );
    });
    test('sudah tercapai -> sekarang', () {
      expect(
        estimateGoalDate(
            target: 100000, current: 100000, netLast30Days: 0, now: now),
        now,
      );
    });
    test('milestone 50/75/100', () {
      expect(milestoneCrossed(40, 55, 100), 50);
      expect(milestoneCrossed(50, 74, 100), 0);
      expect(milestoneCrossed(70, 80, 100), 75);
      expect(milestoneCrossed(90, 100, 100), 100);
      expect(milestoneCrossed(10, 100, 100), 100);
    });
  });
}
