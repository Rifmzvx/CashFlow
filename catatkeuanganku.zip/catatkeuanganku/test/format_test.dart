import 'package:catatkeuanganku/core/format.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('formatRupiah', () {
    expect(formatRupiah(0), 'Rp0');
    expect(formatRupiah(999), 'Rp999');
    expect(formatRupiah(1500000), 'Rp1.500.000');
    expect(formatRupiah(-5000), '-Rp5.000');
    expect(formatRupiah(50000, withSymbol: false), '50.000');
  });

  test('parseRupiah', () {
    expect(parseRupiah('50.000'), 50000);
    expect(parseRupiah('Rp 1.250.000'), 1250000);
    expect(parseRupiah(''), 0);
  });

  test('input nominal otomatis berformat', () {
    final f = RupiahInputFormatter();
    final r = f.formatEditUpdate(
      TextEditingValue.empty,
      const TextEditingValue(text: '50000'),
    );
    expect(r.text, '50.000');
    final empty = f.formatEditUpdate(
      const TextEditingValue(text: '5'),
      const TextEditingValue(text: ''),
    );
    expect(empty.text, '');
  });

  test('tanggal dan bulan', () {
    final d = DateTime.utc(2026, 10, 18, 17, 30);
    expect(formatDate(d), '18 Okt 2026');
    expect(formatTime(d), '17:30');
    expect(formatMonth(d), 'Oktober 2026');
  });
}
