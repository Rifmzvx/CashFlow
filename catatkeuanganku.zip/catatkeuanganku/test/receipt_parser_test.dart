import 'package:catatkeuanganku/logic/receipt_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('membaca toko, tanggal, dan total (abaikan subtotal)', () {
    const text = '''
TOKO MAKMUR JAYA
Jl. Merdeka No. 1
18/10/2026 17:30
Indomie        3.500
Teh Botol      5.000
Subtotal       8.500
PPN              850
TOTAL          9.350
Tunai         10.000
''';
    final r = parseReceipt(text);
    expect(r.merchant, 'TOKO MAKMUR JAYA');
    expect(r.date, DateTime.utc(2026, 10, 18));
    expect(r.total, 9350);
  });

  test('total di baris berikutnya', () {
    final r = parseReceipt('Warung Bakso\nTotal\nRp 25.000');
    expect(r.total, 25000);
  });

  test('tanpa kata kunci: ambil angka terbesar', () {
    final r = parseReceipt('Kedai Kopi\n12.000\n18.000');
    expect(r.total, 18000);
  });

  test('teks kosong tidak error', () {
    final r = parseReceipt('');
    expect(r.total, isNull);
    expect(r.merchant, isNull);
    expect(r.date, isNull);
  });
}
