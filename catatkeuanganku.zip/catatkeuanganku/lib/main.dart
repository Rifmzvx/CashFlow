import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'data/db.dart';
import 'data/repository.dart';
import 'providers.dart';
import 'services/lock_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final db = await AppDb.open();
  final repo = Repo(db);
  // Bersihkan transaksi yang sudah > 30 hari di tempat sampah.
  await repo.purgeTrash(days: 30);

  final lock = LockService();
  await lock.load();

  final prefs = await SharedPreferences.getInstance();
  final onboarded = prefs.getBool('onboarded') ?? false;

  runApp(
    ProviderScope(
      overrides: [
        repoProvider.overrideWithValue(repo),
        lockProvider.overrideWithValue(lock),
      ],
      child: CatatApp(onboarded: onboarded),
    ),
  );
}
