import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'core/theme.dart';
import 'data/db.dart';
import 'data/repository.dart';
import 'providers.dart';
import 'services/lock_service.dart';

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    // Tampilan pertama langsung digambar; persiapan data berjalan di dalamnya.
    runApp(const BootApp());
  }, (error, stack) {
    debugPrint('Kesalahan tak tertangani: $error\n$stack');
  });
}

class _Boot {
  const _Boot(this.repo, this.lock, this.onboarded);
  final Repo repo;
  final LockService lock;
  final bool onboarded;
}

/// Menyiapkan database, kunci, dan pengaturan, sambil menampilkan langkah
/// yang sedang berjalan. Jika ada yang gagal, pesan error ditampilkan
/// (bukan layar kosong) supaya mudah dilacak.
class BootApp extends StatefulWidget {
  const BootApp({super.key});

  @override
  State<BootApp> createState() => _BootAppState();
}

class _BootAppState extends State<BootApp> {
  String _step = 'Memulai...';
  Object? _error;
  StackTrace? _stack;
  _Boot? _boot;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<T> _run<T>(String label, Future<T> Function() job,
      {Duration timeout = const Duration(seconds: 20)}) async {
    if (mounted) setState(() => _step = label);
    try {
      return await job().timeout(timeout);
    } on TimeoutException {
      throw 'Langkah "$label" tidak selesai dalam ${timeout.inSeconds} detik.';
    }
  }

  Future<void> _start() async {
    setState(() {
      _error = null;
      _stack = null;
      _step = 'Memulai...';
    });
    try {
      final db = await _run('Membuka database', AppDb.open);
      final repo = Repo(db);
      // Bersihkan transaksi yang sudah > 30 hari di tempat sampah.
      await _run('Merapikan tempat sampah', () => repo.purgeTrash(days: 30));

      final lock = LockService();
      try {
        await _run('Membaca pengaturan keamanan', lock.load,
            timeout: const Duration(seconds: 8));
      } catch (e) {
        // Penyimpanan aman bermasalah di sebagian HP: lanjut tanpa kunci.
        debugPrint('Penyimpanan aman gagal, lanjut tanpa kunci: $e');
      }

      final prefs = await _run('Membaca pengaturan', SharedPreferences.getInstance);
      if (!mounted) return;
      setState(() => _boot = _Boot(repo, lock, prefs.getBool('onboarded') ?? false));
    } catch (e, s) {
      if (!mounted) return;
      setState(() {
        _error = e;
        _stack = s;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final boot = _boot;
    if (boot != null) {
      return ProviderScope(
        overrides: [
          repoProvider.overrideWithValue(boot.repo),
          lockProvider.overrideWithValue(boot.lock),
        ],
        child: CatatApp(onboarded: boot.onboarded),
      );
    }

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: Scaffold(
        body: SafeArea(
          child: Center(
            child: _error == null
                ? Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 16),
                      Text(_step),
                    ],
                  )
                : SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Aplikasi gagal dimulai',
                            style: Theme.of(context).textTheme.titleLarge),
                        const SizedBox(height: 8),
                        Text('Langkah terakhir: $_step'),
                        const SizedBox(height: 16),
                        SelectableText('$_error\n\n$_stack',
                            style: const TextStyle(fontSize: 11)),
                        const SizedBox(height: 16),
                        FilledButton(onPressed: _start, child: const Text('Coba lagi')),
                      ],
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
