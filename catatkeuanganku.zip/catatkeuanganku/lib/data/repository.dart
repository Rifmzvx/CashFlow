import 'dart:convert';
import 'dart:io';

import 'package:sqflite/sqflite.dart';

import '../core/format.dart';
import '../logic/balance.dart';
import 'models.dart';

/// Filter pencarian transaksi.
class TrxFilter {
  TrxFilter({
    this.query,
    this.type,
    this.walletId,
    this.categoryId,
    this.savingsId,
    this.from,
    this.to,
  });

  String? query;
  String? type;
  int? walletId;
  int? categoryId;
  int? savingsId;
  DateTime? from;
  DateTime? to; // eksklusif

  bool get isActive =>
      (query != null && query!.trim().isNotEmpty) ||
      type != null ||
      walletId != null ||
      categoryId != null ||
      from != null ||
      to != null;

  TrxFilter copy() => TrxFilter(
        query: query,
        type: type,
        walletId: walletId,
        categoryId: categoryId,
        savingsId: savingsId,
        from: from,
        to: to,
      );
}

/// Semua akses data lewat sini. Setiap perubahan ditulis atomik
/// (satu transaksi database) bersama catatan audit-nya.
class Repo {
  Repo(this.db);
  final Database db;

  Future<void> _audit(
    DatabaseExecutor e,
    String entity,
    int? id,
    String action, {
    Object? oldV,
    Object? newV,
  }) async {
    await e.insert('audit_logs', {
      'entity': entity,
      'entity_id': id,
      'action': action,
      'old_json': oldV == null ? null : jsonEncode(oldV),
      'new_json': newV == null ? null : jsonEncode(newV),
      'created_at': wibNow().toIso8601String(),
    });
  }

  // ---------- Dompet ----------
  Future<List<Wallet>> wallets() async {
    final rows = await db.query('wallets', orderBy: 'archived ASC, id ASC');
    return rows.map(Wallet.fromMap).toList();
  }

  Future<int> addWallet(Wallet w) => db.transaction((txn) async {
        final id = await txn.insert('wallets', w.toMap());
        await _audit(txn, 'wallet', id, 'create', newV: w.toMap());
        return id;
      });

  Future<void> updateWallet(Wallet w) => db.transaction((txn) async {
        final old = await txn.query('wallets', where: 'id = ?', whereArgs: [w.id]);
        await txn.update('wallets', w.toMap(), where: 'id = ?', whereArgs: [w.id]);
        await _audit(txn, 'wallet', w.id, 'update',
            oldV: old.isEmpty ? null : old.first, newV: w.toMap());
      });

  // ---------- Kategori ----------
  Future<List<Category>> categories() async {
    final rows = await db.query('categories', orderBy: 'type ASC, id ASC');
    return rows.map(Category.fromMap).toList();
  }

  Future<int> addCategory(Category c) => db.transaction((txn) async {
        final id = await txn.insert('categories', c.toMap());
        await _audit(txn, 'category', id, 'create', newV: c.toMap());
        return id;
      });

  Future<void> updateCategory(Category c) => db.transaction((txn) async {
        final old = await txn.query('categories', where: 'id = ?', whereArgs: [c.id]);
        await txn.update('categories', c.toMap(), where: 'id = ?', whereArgs: [c.id]);
        await _audit(txn, 'category', c.id, 'update',
            oldV: old.isEmpty ? null : old.first, newV: c.toMap());
      });

  // ---------- Tabungan ----------
  Future<List<SavingsGoal>> goals() async {
    final rows = await db.query('savings_goals', orderBy: 'archived ASC, id ASC');
    return rows.map(SavingsGoal.fromMap).toList();
  }

  Future<int> addGoal(SavingsGoal g) => db.transaction((txn) async {
        final id = await txn.insert('savings_goals', g.toMap());
        await _audit(txn, 'savings', id, 'create', newV: g.toMap());
        return id;
      });

  Future<void> updateGoal(SavingsGoal g) => db.transaction((txn) async {
        final old = await txn.query('savings_goals', where: 'id = ?', whereArgs: [g.id]);
        await txn.update('savings_goals', g.toMap(), where: 'id = ?', whereArgs: [g.id]);
        await _audit(txn, 'savings', g.id, 'update',
            oldV: old.isEmpty ? null : old.first, newV: g.toMap());
      });

  // ---------- Transaksi ----------
  Future<String> _nextNumber(DatabaseExecutor e, int year) async {
    final rows = await e.query(
      'transactions',
      columns: ['trx_number'],
      where: 'trx_number LIKE ?',
      whereArgs: ['TRX-$year-%'],
      orderBy: 'length(trx_number) DESC, trx_number DESC',
      limit: 1,
    );
    // Nomor dihitung dari SEMUA baris (termasuk yang di tempat sampah)
    // supaya nomor tidak pernah dipakai ulang.
    return nextTrxNumber(year, rows.isEmpty ? null : rows.first['trx_number'] as String);
  }

  Future<void> _syncAttachments(DatabaseExecutor e, int trxId, List<String> paths) async {
    final existing = await e.query('attachments',
        where: 'transaction_id = ?', whereArgs: [trxId]);
    final have = existing.map((r) => r['file_path'] as String).toSet();
    for (final r in existing) {
      if (!paths.contains(r['file_path'])) {
        await e.delete('attachments', where: 'id = ?', whereArgs: [r['id']]);
      }
    }
    for (final path in paths) {
      if (!have.contains(path)) {
        await e.insert('attachments', {
          'transaction_id': trxId,
          'file_path': path,
          'kind': path.toLowerCase().endsWith('.pdf') ? 'pdf' : 'photo',
          'created_at': wibNow().toIso8601String(),
        });
      }
    }
  }

  Future<int> addTrx(Trx t, {List<String> attachments = const []}) =>
      db.transaction((txn) async {
        final now = wibNow();
        final number = await _nextNumber(txn, now.year);
        final map = t.toMap()
          ..['trx_number'] = number
          ..['created_at'] = now.toIso8601String()
          ..['updated_at'] = now.toIso8601String();
        final id = await txn.insert('transactions', map);
        await _syncAttachments(txn, id, attachments);
        await _audit(txn, 'transaction', id, 'create', newV: map);
        return id;
      });

  Future<void> updateTrx(Trx t, {List<String> attachments = const []}) =>
      db.transaction((txn) async {
        final old = await txn.query('transactions', where: 'id = ?', whereArgs: [t.id]);
        final map = t.toMap()
          ..remove('trx_number')
          ..['updated_at'] = wibNow().toIso8601String();
        await txn.update('transactions', map, where: 'id = ?', whereArgs: [t.id]);
        await _syncAttachments(txn, t.id!, attachments);
        await _audit(txn, 'transaction', t.id, 'update',
            oldV: old.isEmpty ? null : old.first, newV: map);
      });

  /// Hapus lunak: transaksi pindah ke tempat sampah, bisa dipulihkan.
  Future<void> softDeleteTrx(int id) => db.transaction((txn) async {
        await txn.update(
          'transactions',
          {'deleted_at': wibNow().toIso8601String()},
          where: 'id = ?',
          whereArgs: [id],
        );
        await _audit(txn, 'transaction', id, 'delete');
      });

  Future<void> restoreTrx(int id) => db.transaction((txn) async {
        await txn.update('transactions', {'deleted_at': null},
            where: 'id = ?', whereArgs: [id]);
        await _audit(txn, 'transaction', id, 'restore');
      });

  /// Hapus permanen transaksi yang sudah > [days] hari di tempat sampah.
  Future<int> purgeTrash({int days = 30}) async {
    final cutoff = wibNow().subtract(Duration(days: days)).toIso8601String();
    final rows = await db.query('transactions',
        columns: ['id'],
        where: 'deleted_at IS NOT NULL AND deleted_at < ?',
        whereArgs: [cutoff]);
    var purged = 0;
    for (final r in rows) {
      final id = r['id'] as int;
      final files = await attachmentPaths(id);
      await db.transaction((txn) async {
        await txn.delete('transactions', where: 'id = ?', whereArgs: [id]);
        await _audit(txn, 'transaction', id, 'purge');
      });
      for (final f in files) {
        try {
          final file = File(f);
          if (await file.exists()) await file.delete();
        } catch (_) {}
      }
      purged++;
    }
    return purged;
  }

  Future<List<String>> attachmentPaths(int trxId) async {
    final rows = await db.query('attachments',
        where: 'transaction_id = ?', whereArgs: [trxId], orderBy: 'id ASC');
    return rows.map((r) => r['file_path'] as String).toList();
  }

  Future<List<Trx>> trxList({
    TrxFilter? filter,
    bool deleted = false,
    bool ascending = false,
    int limit = 30,
    int offset = 0,
  }) async {
    final where = <String>[deleted ? 'deleted_at IS NOT NULL' : 'deleted_at IS NULL'];
    final args = <Object?>[];
    final f = filter;
    if (f != null) {
      if (f.type != null) {
        where.add('type = ?');
        args.add(f.type);
      }
      if (f.savingsId != null) {
        where.add('savings_id = ?');
        args.add(f.savingsId);
      }
      if (f.walletId != null) {
        where.add('(wallet_id = ? OR to_wallet_id = ?)');
        args..add(f.walletId)..add(f.walletId);
      }
      if (f.categoryId != null) {
        where.add('category_id = ?');
        args.add(f.categoryId);
      }
      if (f.from != null) {
        where.add('occurred_at >= ?');
        args.add(f.from!.toIso8601String());
      }
      if (f.to != null) {
        where.add('occurred_at < ?');
        args.add(f.to!.toIso8601String());
      }
      final q = f.query?.trim() ?? '';
      if (q.isNotEmpty) {
        where.add('(note LIKE ? OR trx_number LIKE ?)');
        args..add('%$q%')..add('%$q%');
      }
    }
    final dir = ascending ? 'ASC' : 'DESC';
    final rows = await db.query(
      'transactions',
      where: where.join(' AND '),
      whereArgs: args,
      orderBy: deleted ? 'deleted_at DESC' : 'occurred_at $dir, id $dir',
      limit: limit,
      offset: offset,
    );
    return rows.map(Trx.fromMap).toList();
  }

  /// Seluruh transaksi aktif dalam bentuk ringkas, untuk hitung saldo.
  Future<List<TrxLite>> activeLite() async {
    final rows = await db.query(
      'transactions',
      columns: ['type', 'amount', 'wallet_id', 'to_wallet_id', 'savings_id', 'occurred_at'],
      where: 'deleted_at IS NULL',
    );
    return rows
        .map((r) => TrxLite(
              type: r['type'] as String,
              amount: r['amount'] as int,
              walletId: r['wallet_id'] as int?,
              toWalletId: r['to_wallet_id'] as int?,
              savingsId: r['savings_id'] as int?,
              occurredAt: DateTime.parse(r['occurred_at'] as String),
            ))
        .toList();
  }

  // ---------- Laporan ----------
  Future<MonthTotals> monthTotals(DateTime month) async {
    final from = monthStart(month).toIso8601String();
    final to = nextMonth(month).toIso8601String();
    Future<int> sum(String type) async {
      final r = await db.rawQuery(
        'SELECT COALESCE(SUM(amount),0) AS s FROM transactions '
        'WHERE deleted_at IS NULL AND type = ? AND occurred_at >= ? AND occurred_at < ?',
        [type, from, to],
      );
      return (r.first['s'] as int?) ?? 0;
    }

    return MonthTotals(monthStart(month), await sum(TrxType.income), await sum(TrxType.expense));
  }

  Future<List<CatTotal>> expenseByCategory(DateTime month) async {
    final rows = await db.rawQuery(
      'SELECT category_id, SUM(amount) AS s FROM transactions '
      'WHERE deleted_at IS NULL AND type = ? AND occurred_at >= ? AND occurred_at < ? '
      'GROUP BY category_id ORDER BY s DESC',
      [TrxType.expense, monthStart(month).toIso8601String(), nextMonth(month).toIso8601String()],
    );
    return rows.map((r) => CatTotal(r['category_id'] as int?, (r['s'] as int?) ?? 0)).toList();
  }

  // ---------- Riwayat perubahan ----------
  Future<List<AuditEntry>> audits({int limit = 300}) async {
    final rows = await db.query('audit_logs', orderBy: 'id DESC', limit: limit);
    return rows.map(AuditEntry.fromMap).toList();
  }
}
