import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../core/format.dart';

/// Versi skema database. Naikkan saat struktur tabel berubah,
/// lalu tambahkan langkah migrasi di [_onUpgrade].
const int kSchemaVersion = 1;

class AppDb {
  static Database? _db;

  static Future<Database> open() async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dir, 'catatkeuanganku.db'),
      version: kSchemaVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
    return _db!;
  }

  static Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE wallets(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'wallet',
        color INTEGER NOT NULL DEFAULT 4278225275,
        initial_balance INTEGER NOT NULL DEFAULT 0,
        archived INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )''');
    await db.execute('''
      CREATE TABLE categories(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'other',
        color INTEGER NOT NULL DEFAULT 4284955319,
        is_default INTEGER NOT NULL DEFAULT 0,
        archived INTEGER NOT NULL DEFAULT 0
      )''');
    await db.execute('''
      CREATE TABLE savings_goals(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        icon TEXT NOT NULL DEFAULT 'savings',
        color INTEGER NOT NULL DEFAULT 4278225275,
        target_amount INTEGER NOT NULL DEFAULT 0,
        deadline TEXT,
        archived INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )''');
    await db.execute('''
      CREATE TABLE transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trx_number TEXT NOT NULL UNIQUE,
        type TEXT NOT NULL,
        amount INTEGER NOT NULL,
        wallet_id INTEGER REFERENCES wallets(id),
        to_wallet_id INTEGER REFERENCES wallets(id),
        category_id INTEGER REFERENCES categories(id),
        savings_id INTEGER REFERENCES savings_goals(id),
        note TEXT,
        occurred_at TEXT NOT NULL,
        deleted_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )''');
    await db.execute('''
      CREATE TABLE attachments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id INTEGER NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
        file_path TEXT NOT NULL,
        kind TEXT NOT NULL DEFAULT 'photo',
        created_at TEXT NOT NULL
      )''');
    await db.execute('''
      CREATE TABLE audit_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity TEXT NOT NULL,
        entity_id INTEGER,
        action TEXT NOT NULL,
        old_json TEXT,
        new_json TEXT,
        created_at TEXT NOT NULL
      )''');

    await db.execute('CREATE INDEX idx_trx_occurred ON transactions(occurred_at)');
    await db.execute('CREATE INDEX idx_trx_wallet ON transactions(wallet_id)');
    await db.execute('CREATE INDEX idx_trx_to_wallet ON transactions(to_wallet_id)');
    await db.execute('CREATE INDEX idx_trx_category ON transactions(category_id)');
    await db.execute('CREATE INDEX idx_trx_savings ON transactions(savings_id)');
    await db.execute('CREATE INDEX idx_trx_deleted ON transactions(deleted_at)');
    await db.execute('CREATE INDEX idx_att_trx ON attachments(transaction_id)');

    await _seedCategories(db);
  }

  static Future<void> _seedCategories(Database db) async {
    const income = [
      ['Gaji', 'salary', 0xFF2E9E6B],
      ['Uang Saku', 'allowance', 0xFF26A69A],
      ['Hadiah', 'gift', 0xFFAB47BC],
      ['Penjualan', 'sell', 0xFF5C6BC0],
      ['Lainnya', 'other', 0xFF78909C],
    ];
    const expense = [
      ['Makanan', 'food', 0xFFEF6C00],
      ['Transportasi', 'transport', 0xFF1E88E5],
      ['Tagihan', 'bill', 0xFFD81B60],
      ['Belanja', 'shop', 0xFF8E24AA],
      ['Hiburan', 'fun', 0xFFFDD835],
      ['Sekolah', 'school', 0xFF00ACC1],
      ['Lainnya', 'other', 0xFF78909C],
    ];
    for (final c in income) {
      await db.insert('categories', {
        'name': c[0], 'type': 'income', 'icon': c[1], 'color': c[2], 'is_default': 1,
      });
    }
    for (final c in expense) {
      await db.insert('categories', {
        'name': c[0], 'type': 'expense', 'icon': c[1], 'color': c[2], 'is_default': 1,
      });
    }
    await db.insert('audit_logs', {
      'entity': 'app',
      'entity_id': null,
      'action': 'init',
      'new_json': '{"schema":$kSchemaVersion}',
      'created_at': wibNow().toIso8601String(),
    });
  }

  /// Migrasi berurutan: tiap versi baru menambah satu blok `if`.
  /// Contoh nanti: if (oldV < 2) { await db.execute('ALTER TABLE ...'); }
  static Future<void> _onUpgrade(Database db, int oldV, int newV) async {}
}
