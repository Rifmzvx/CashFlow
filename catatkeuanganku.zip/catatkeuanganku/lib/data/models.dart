import '../core/format.dart';
import '../logic/balance.dart';

class Wallet {
  const Wallet({
    this.id,
    required this.name,
    required this.type,
    this.icon = 'wallet',
    this.color = 0xFF00897B,
    this.initialBalance = 0,
    this.archived = false,
    this.createdAt,
  });

  final int? id;
  final String name;
  final String type; // tunai | bank | ewallet | lainnya
  final String icon;
  final int color;
  final int initialBalance;
  final bool archived;
  final String? createdAt;

  factory Wallet.fromMap(Map<String, Object?> m) => Wallet(
        id: m['id'] as int,
        name: m['name'] as String,
        type: m['type'] as String,
        icon: (m['icon'] as String?) ?? 'wallet',
        color: (m['color'] as int?) ?? 0xFF00897B,
        initialBalance: (m['initial_balance'] as int?) ?? 0,
        archived: ((m['archived'] as int?) ?? 0) == 1,
        createdAt: m['created_at'] as String?,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'type': type,
        'icon': icon,
        'color': color,
        'initial_balance': initialBalance,
        'archived': archived ? 1 : 0,
        'created_at': createdAt ?? wibNow().toIso8601String(),
      };

  Wallet copyWith({
    String? name,
    String? type,
    String? icon,
    int? color,
    int? initialBalance,
    bool? archived,
  }) =>
      Wallet(
        id: id,
        name: name ?? this.name,
        type: type ?? this.type,
        icon: icon ?? this.icon,
        color: color ?? this.color,
        initialBalance: initialBalance ?? this.initialBalance,
        archived: archived ?? this.archived,
        createdAt: createdAt,
      );
}

const walletTypeLabels = {
  'tunai': 'Tunai',
  'bank': 'Rekening Bank',
  'ewallet': 'E-wallet',
  'lainnya': 'Lainnya',
};

class Category {
  const Category({
    this.id,
    required this.name,
    required this.type,
    this.icon = 'other',
    this.color = 0xFF78909C,
    this.isDefault = false,
    this.archived = false,
  });

  final int? id;
  final String name;
  final String type; // income | expense
  final String icon;
  final int color;
  final bool isDefault;
  final bool archived;

  factory Category.fromMap(Map<String, Object?> m) => Category(
        id: m['id'] as int,
        name: m['name'] as String,
        type: m['type'] as String,
        icon: (m['icon'] as String?) ?? 'other',
        color: (m['color'] as int?) ?? 0xFF78909C,
        isDefault: ((m['is_default'] as int?) ?? 0) == 1,
        archived: ((m['archived'] as int?) ?? 0) == 1,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'type': type,
        'icon': icon,
        'color': color,
        'is_default': isDefault ? 1 : 0,
        'archived': archived ? 1 : 0,
      };
}

class SavingsGoal {
  const SavingsGoal({
    this.id,
    required this.name,
    this.icon = 'savings',
    this.color = 0xFF00897B,
    this.targetAmount = 0,
    this.deadline,
    this.archived = false,
    this.createdAt,
  });

  final int? id;
  final String name;
  final String icon;
  final int color;
  final int targetAmount; // 0 = tanpa target
  final DateTime? deadline;
  final bool archived;
  final String? createdAt;

  factory SavingsGoal.fromMap(Map<String, Object?> m) => SavingsGoal(
        id: m['id'] as int,
        name: m['name'] as String,
        icon: (m['icon'] as String?) ?? 'savings',
        color: (m['color'] as int?) ?? 0xFF00897B,
        targetAmount: (m['target_amount'] as int?) ?? 0,
        deadline: m['deadline'] == null ? null : DateTime.parse(m['deadline'] as String),
        archived: ((m['archived'] as int?) ?? 0) == 1,
        createdAt: m['created_at'] as String?,
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'icon': icon,
        'color': color,
        'target_amount': targetAmount,
        'deadline': deadline?.toIso8601String(),
        'archived': archived ? 1 : 0,
        'created_at': createdAt ?? wibNow().toIso8601String(),
      };
}

class Trx {
  const Trx({
    this.id,
    this.trxNumber,
    required this.type,
    required this.amount,
    this.walletId,
    this.toWalletId,
    this.categoryId,
    this.savingsId,
    this.note,
    required this.occurredAt,
    this.deletedAt,
  });

  final int? id;
  final String? trxNumber;
  final String type;
  final int amount;
  final int? walletId;
  final int? toWalletId;
  final int? categoryId;
  final int? savingsId;
  final String? note;
  final DateTime occurredAt;
  final DateTime? deletedAt;

  TrxLite get lite => TrxLite(
        type: type,
        amount: amount,
        walletId: walletId,
        toWalletId: toWalletId,
        savingsId: savingsId,
        occurredAt: occurredAt,
      );

  factory Trx.fromMap(Map<String, Object?> m) => Trx(
        id: m['id'] as int,
        trxNumber: m['trx_number'] as String?,
        type: m['type'] as String,
        amount: m['amount'] as int,
        walletId: m['wallet_id'] as int?,
        toWalletId: m['to_wallet_id'] as int?,
        categoryId: m['category_id'] as int?,
        savingsId: m['savings_id'] as int?,
        note: m['note'] as String?,
        occurredAt: DateTime.parse(m['occurred_at'] as String),
        deletedAt:
            m['deleted_at'] == null ? null : DateTime.parse(m['deleted_at'] as String),
      );

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        if (trxNumber != null) 'trx_number': trxNumber,
        'type': type,
        'amount': amount,
        'wallet_id': walletId,
        'to_wallet_id': toWalletId,
        'category_id': categoryId,
        'savings_id': savingsId,
        'note': note,
        'occurred_at': occurredAt.toIso8601String(),
        'deleted_at': deletedAt?.toIso8601String(),
      };
}

class AuditEntry {
  const AuditEntry({
    required this.id,
    required this.entity,
    this.entityId,
    required this.action,
    this.oldJson,
    this.newJson,
    required this.createdAt,
  });

  final int id;
  final String entity;
  final int? entityId;
  final String action;
  final String? oldJson;
  final String? newJson;
  final DateTime createdAt;

  factory AuditEntry.fromMap(Map<String, Object?> m) => AuditEntry(
        id: m['id'] as int,
        entity: m['entity'] as String,
        entityId: m['entity_id'] as int?,
        action: m['action'] as String,
        oldJson: m['old_json'] as String?,
        newJson: m['new_json'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
}

class MonthTotals {
  const MonthTotals(this.month, this.income, this.expense);
  final DateTime month;
  final int income;
  final int expense;
  int get net => income - expense;
}

class CatTotal {
  const CatTotal(this.categoryId, this.total);
  final int? categoryId;
  final int total;
}
