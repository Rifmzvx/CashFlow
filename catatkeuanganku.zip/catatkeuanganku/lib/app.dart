import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'core/theme.dart';
import 'providers.dart';
import 'ui/add_transaction.dart';
import 'ui/home_page.dart';
import 'ui/lock_screen.dart';
import 'ui/more_page.dart';
import 'ui/onboarding.dart';
import 'ui/reports_page.dart';
import 'ui/savings_page.dart';
import 'ui/transactions_page.dart';
import 'ui/widgets.dart';
import 'logic/balance.dart';

class CatatApp extends StatelessWidget {
  const CatatApp({super.key, required this.onboarded});
  final bool onboarded;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CatatKeuanganKu',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: AppRoot(onboarded: onboarded),
    );
  }
}

/// Urutan tampilan: kunci PIN -> onboarding -> aplikasi utama.
class AppRoot extends ConsumerStatefulWidget {
  const AppRoot({super.key, required this.onboarded});
  final bool onboarded;

  @override
  ConsumerState<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends ConsumerState<AppRoot> with WidgetsBindingObserver {
  late bool _onboarded = widget.onboarded;
  DateTime? _pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// Kunci otomatis jika aplikasi di latar belakang > 30 detik.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final lock = ref.read(lockProvider);
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final p = _pausedAt;
      if (p != null && DateTime.now().difference(p).inSeconds > 30) lock.lock();
      _pausedAt = null;
    }
  }

  Future<void> _finishOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarded', true);
    setState(() => _onboarded = true);
  }

  @override
  Widget build(BuildContext context) {
    final lock = ref.watch(lockProvider);
    return ListenableBuilder(
      listenable: lock,
      builder: (context, _) {
        if (lock.locked) return LockScreen(lock: lock);
        if (!_onboarded) return OnboardingScreen(onDone: _finishOnboarding);
        return const MainShell();
      },
    );
  }
}

class MainShell extends ConsumerStatefulWidget {
  const MainShell({super.key});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _index = 0;

  static const _pages = <Widget>[
    HomePage(),
    TransactionsPage(),
    SavingsPage(),
    ReportsPage(),
    MorePage(),
  ];

  void _openAddMenu() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.arrow_downward, color: kIncome),
              title: const Text('Pemasukan'),
              onTap: () {
                Navigator.pop(c);
                push(context, const AddTransactionScreen(initialType: TrxType.income));
              },
            ),
            ListTile(
              leading: const Icon(Icons.arrow_upward, color: kExpense),
              title: const Text('Pengeluaran'),
              onTap: () {
                Navigator.pop(c);
                push(context, const AddTransactionScreen(initialType: TrxType.expense));
              },
            ),
            ListTile(
              leading: const Icon(Icons.swap_horiz),
              title: const Text('Transfer antar dompet'),
              onTap: () {
                Navigator.pop(c);
                push(context, const AddTransactionScreen(initialType: TrxType.transfer));
              },
            ),
            ListTile(
              leading: const Icon(Icons.document_scanner_outlined),
              title: const Text('Scan struk'),
              onTap: () {
                Navigator.pop(c);
                push(context,
                    const AddTransactionScreen(initialType: TrxType.expense, startWithScan: true));
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _index, children: _pages)),
      floatingActionButton: FloatingActionButton(
        onPressed: _openAddMenu,
        tooltip: 'Tambah transaksi',
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transaksi'),
          NavigationDestination(icon: Icon(Icons.savings_outlined), selectedIcon: Icon(Icons.savings), label: 'Tabungan'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Laporan'),
          NavigationDestination(icon: Icon(Icons.menu), selectedIcon: Icon(Icons.menu_open), label: 'Lainnya'),
        ],
      ),
    );
  }
}
