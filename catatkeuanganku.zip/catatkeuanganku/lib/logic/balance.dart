/// Logika murni (tanpa Flutter/database) agar mudah diuji.
library;

class TrxType {
  static const income = 'income';
  static const expense = 'expense';
  static const transfer = 'transfer';
  static const adjustment = 'adjustment';
  static const savingIn = 'saving_in';
  static const savingOut = 'saving_out';
}

/// Versi ringkas transaksi untuk menghitung saldo.
class TrxLite {
  const TrxLite({
    required this.type,
    required this.amount,
    this.walletId,
    this.toWalletId,
    this.savingsId,
    this.occurredAt,
  });

  final String type;
  final int amount; // adjustment boleh negatif, jenis lain selalu positif
  final int? walletId;
  final int? toWalletId;
  final int? savingsId;
  final DateTime? occurredAt;
}

/// Pengaruh satu transaksi terhadap saldo sebuah dompet.
int walletDelta(TrxLite t, int walletId) {
  switch (t.type) {
    case TrxType.income:
    case TrxType.adjustment:
    case TrxType.savingOut: // tarik dari tabungan masuk ke dompet
      return t.walletId == walletId ? t.amount : 0;
    case TrxType.expense:
    case TrxType.savingIn: // setor ke tabungan keluar dari dompet
      return t.walletId == walletId ? -t.amount : 0;
    case TrxType.transfer:
      var d = 0;
      if (t.walletId == walletId) d -= t.amount;
      if (t.toWalletId == walletId) d += t.amount;
      return d;
  }
  return 0;
}

/// Pengaruh satu transaksi terhadap saldo sebuah tabungan.
int savingsDelta(TrxLite t, int savingsId) {
  if (t.savingsId != savingsId) return 0;
  if (t.type == TrxType.savingIn) return t.amount;
  if (t.type == TrxType.savingOut) return -t.amount;
  return 0;
}

/// Saldo dompet = saldo awal + seluruh transaksi aktif.
int walletBalance({
  required int walletId,
  required int initialBalance,
  required Iterable<TrxLite> trxs,
}) {
  var total = initialBalance;
  for (final t in trxs) {
    total += walletDelta(t, walletId);
  }
  return total;
}

int savingsBalance(int savingsId, Iterable<TrxLite> trxs) {
  var total = 0;
  for (final t in trxs) {
    total += savingsDelta(t, savingsId);
  }
  return total;
}

/// Mengembalikan pesan kesalahan, atau null jika transaksi valid.
String? validateTrx({
  required String type,
  required int amount,
  int? walletId,
  int? toWalletId,
  int? savingsId,
}) {
  if (type == TrxType.adjustment) {
    if (amount == 0) return 'Selisih saldo tidak boleh nol';
  } else if (amount <= 0) {
    return 'Nominal harus lebih dari 0';
  }
  switch (type) {
    case TrxType.income:
    case TrxType.expense:
    case TrxType.adjustment:
      if (walletId == null) return 'Pilih dompet';
    case TrxType.transfer:
      if (walletId == null || toWalletId == null) {
        return 'Pilih dompet asal dan tujuan';
      }
      if (walletId == toWalletId) {
        return 'Dompet asal dan tujuan tidak boleh sama';
      }
    case TrxType.savingIn:
    case TrxType.savingOut:
      if (savingsId == null) return 'Pilih tabungan';
  }
  return null;
}

/// Nomor transaksi berikutnya: TRX-2026-0001, TRX-2026-0002, ...
String nextTrxNumber(int year, String? lastNumber) {
  var seq = 0;
  if (lastNumber != null) {
    final parts = lastNumber.split('-');
    if (parts.length == 3 && parts[1] == year.toString()) {
      seq = int.tryParse(parts[2]) ?? 0;
    }
  }
  return 'TRX-$year-${(seq + 1).toString().padLeft(4, '0')}';
}

/// Perkiraan tanggal target tercapai dari rata-rata setoran bersih 30 hari.
/// Null jika belum bisa diperkirakan (tidak ada setoran bersih positif).
DateTime? estimateGoalDate({
  required int target,
  required int current,
  required int netLast30Days,
  required DateTime now,
}) {
  if (target <= 0) return null;
  if (current >= target) return now;
  if (netLast30Days <= 0) return null;
  final perDay = netLast30Days / 30.0;
  final days = ((target - current) / perDay).ceil();
  if (days > 36500) return null;
  return now.add(Duration(days: days));
}

/// Batas progres terbesar (50/75/100) yang baru terlewati, atau 0.
int milestoneCrossed(int before, int after, int target) {
  if (target <= 0) return 0;
  int pct(int v) => (v * 100) ~/ target;
  final b = pct(before);
  final a = pct(after);
  for (final m in const [100, 75, 50]) {
    if (b < m && a >= m) return m;
  }
  return 0;
}
