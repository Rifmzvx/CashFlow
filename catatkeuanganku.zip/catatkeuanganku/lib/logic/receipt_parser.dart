/// Membaca hasil OCR struk: total, nama toko, dan tanggal.
library;

class ReceiptData {
  const ReceiptData({this.total, this.merchant, this.date});
  final int? total;
  final String? merchant;
  final DateTime? date;
}

final _numberRe = RegExp(r'\d{1,3}(?:[.,]\d{3})+(?:,\d{2})?|\d+');
final _totalKeyRe =
    RegExp(r'(grand\s*total|total|jumlah|tagihan|amount\s*due)', caseSensitive: false);
final _subTotalRe = RegExp(r'sub\s*total', caseSensitive: false);
final _dateRe = RegExp(r'(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})');

int? _toInt(String raw) {
  var s = raw;
  // buang desimal ",00" di belakang angka yang punya pemisah ribuan
  if (RegExp(r'[.,]\d{3}').hasMatch(s)) {
    s = s.replaceAll(RegExp(r',\d{2}$'), '');
  }
  final digits = s.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.isEmpty || digits.length > 10) return null;
  return int.parse(digits);
}

List<int> _numbersIn(String line) {
  return _numberRe
      .allMatches(line)
      .map((m) => _toInt(m.group(0)!))
      .whereType<int>()
      .toList();
}

ReceiptData parseReceipt(String text) {
  final lines = text
      .split('\n')
      .map((l) => l.trim())
      .where((l) => l.isNotEmpty)
      .toList();

  // Total: cari baris berkata kunci "total", abaikan "subtotal".
  final candidates = <int>[];
  for (var i = 0; i < lines.length; i++) {
    final l = lines[i];
    if (_totalKeyRe.hasMatch(l) && !_subTotalRe.hasMatch(l)) {
      var nums = _numbersIn(l);
      if (nums.isEmpty && i + 1 < lines.length) nums = _numbersIn(lines[i + 1]);
      candidates.addAll(nums.where((n) => n >= 100));
    }
  }
  int? total;
  if (candidates.isNotEmpty) {
    total = candidates.reduce((a, b) => a > b ? a : b);
  } else {
    final all = lines.expand(_numbersIn).where((n) => n >= 100).toList();
    if (all.isNotEmpty) total = all.reduce((a, b) => a > b ? a : b);
  }

  // Nama toko: baris pertama yang berisi minimal 3 huruf.
  String? merchant;
  for (final l in lines) {
    if (RegExp(r'[A-Za-z]{3,}').hasMatch(l)) {
      merchant = l;
      break;
    }
  }

  // Tanggal dd/mm/yyyy atau dd-mm-yy.
  DateTime? date;
  for (final l in lines) {
    final m = _dateRe.firstMatch(l);
    if (m == null) continue;
    final d = int.parse(m.group(1)!);
    final mo = int.parse(m.group(2)!);
    var y = int.parse(m.group(3)!);
    if (y < 100) y += 2000;
    if (d >= 1 && d <= 31 && mo >= 1 && mo <= 12 && y >= 2000 && y <= 2100) {
      date = DateTime.utc(y, mo, d);
      break;
    }
  }

  return ReceiptData(total: total, merchant: merchant, date: date);
}
