import 'dart:io';

import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

const int kMaxPhotoBytes = 300 * 1024;

/// Ambil foto dari kamera/galeri lalu kompres hingga <= 300 KB
/// dan simpan di folder aplikasi. Mengembalikan path file, atau null jika batal.
Future<String?> pickAndCompress(ImageSource source) async {
  final picked = await ImagePicker().pickImage(source: source);
  if (picked == null) return null;
  return compressToAppDir(picked.path);
}

Future<String> compressToAppDir(String inputPath) async {
  final base = await getApplicationDocumentsDirectory();
  final dir = Directory(p.join(base.path, 'bukti'));
  await dir.create(recursive: true);
  final target = p.join(dir.path, '${DateTime.now().microsecondsSinceEpoch}.jpg');

  var quality = 80;
  XFile? out;
  for (var i = 0; i < 4; i++) {
    out = await FlutterImageCompress.compressAndGetFile(
      inputPath,
      target,
      quality: quality,
      minWidth: 1280,
      minHeight: 1280,
      format: CompressFormat.jpeg,
    );
    if (out == null) break;
    if (await out.length() <= kMaxPhotoBytes) break;
    quality -= 15;
  }
  if (out == null) {
    // Kompresi gagal: salin apa adanya agar bukti tetap tersimpan.
    await File(inputPath).copy(target);
    return target;
  }
  return out.path;
}
