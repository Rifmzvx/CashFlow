import 'package:flutter/services.dart';

/// Format rupiah: 1500000 -> "Rp1.500.000", -5000 -> "-Rp5.000".
String formatRupiah(int amount, {bool withSymbol = true}) {
  final negative = amount < 0;
  final digits = amount.abs().toString();
  final buf = StringBuffer();
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buf.write('.');
    buf.write(digits[i]);
  }
  return '${negative ? '-' : ''}${withSymbol ? 'Rp' : ''}$buf';
}

/// Ambil angka dari teks input ("50.000" -> 50000). Dibatasi 13 digit.
int parseRupiah(String s) {
  var d = s.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.length > 13) d = d.substring(0, 13);
  return d.isEmpty ? 0 : int.parse(d);
}

/// Waktu sekarang dalam WIB (UTC+7). Disimpan sebagai jam dinding WIB
/// dengan flag UTC, supaya tampilan tidak bergantung zona waktu HP.
DateTime wibNow() => DateTime.now().toUtc().add(const Duration(hours: 7));

DateTime monthStart(DateTime d) => DateTime.utc(d.year, d.month, 1);
DateTime nextMonth(DateTime d) => DateTime.utc(d.year, d.month + 1, 1);

const _bulanPendek = [
  'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
  'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'
];
const _bulanPanjang = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

String bulanPendek(int month) => _bulanPendek[month - 1];
String formatMonth(DateTime d) => '${_bulanPanjang[d.month - 1]} ${d.year}';
String formatDate(DateTime d) => '${d.day} ${_bulanPendek[d.month - 1]} ${d.year}';
String _two(int n) => n.toString().padLeft(2, '0');
String formatTime(DateTime d) => '${_two(d.hour)}:${_two(d.minute)}';
String formatDateTime(DateTime d) => '${formatDate(d)} ${formatTime(d)}';

/// Input nominal otomatis berformat: ketik 50000 tampil 50.000.
class RupiahInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final value = parseRupiah(newValue.text);
    if (newValue.text.replaceAll(RegExp(r'[^0-9]'), '').isEmpty) {
      return const TextEditingValue(text: '');
    }
    final text = formatRupiah(value, withSymbol: false);
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}
