import 'package:flutter/material.dart';

const Map<String, IconData> kIcons = {
  'wallet': Icons.account_balance_wallet,
  'cash': Icons.payments,
  'bank': Icons.account_balance,
  'phone': Icons.smartphone,
  'savings': Icons.savings,
  'school': Icons.school,
  'travel': Icons.beach_access,
  'health': Icons.health_and_safety,
  'food': Icons.restaurant,
  'transport': Icons.directions_bus,
  'bill': Icons.receipt_long,
  'shop': Icons.shopping_bag,
  'fun': Icons.sports_esports,
  'gift': Icons.card_giftcard,
  'salary': Icons.work,
  'sell': Icons.storefront,
  'allowance': Icons.child_care,
  'emergency': Icons.shield,
  'home': Icons.home,
  'star': Icons.star,
  'other': Icons.category,
};

IconData iconOf(String? key) => kIcons[key] ?? Icons.category;

const List<int> kPalette = [
  0xFF00897B, 0xFF2E9E6B, 0xFF1E88E5, 0xFF5C6BC0, 0xFF8E24AA,
  0xFFD81B60, 0xFFEF6C00, 0xFFFDD835, 0xFF00ACC1, 0xFF78909C,
];

const Map<String, String> kWalletIconByType = {
  'tunai': 'cash',
  'bank': 'bank',
  'ewallet': 'phone',
  'lainnya': 'wallet',
};
