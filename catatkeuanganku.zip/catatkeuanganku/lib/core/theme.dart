import 'package:flutter/material.dart';

const kPrimary = Color(0xFF00897B);
const kIncome = Color(0xFF2E9E6B);
const kExpense = Color(0xFFD9534F);

/// Material 3, hijau-tosca. Jarak antar elemen memakai kelipatan 8.
ThemeData buildTheme(Brightness brightness) {
  final scheme = ColorScheme.fromSeed(seedColor: kPrimary, brightness: brightness);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: scheme.surface,
    appBarTheme: AppBarTheme(
      centerTitle: false,
      backgroundColor: scheme.surface,
      scrolledUnderElevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
    ),
    navigationBarTheme: const NavigationBarThemeData(height: 68),
  );
}
