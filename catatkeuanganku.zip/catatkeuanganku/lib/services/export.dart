import 'dart:io';

import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../core/format.dart';
import '../data/models.dart';
import '../logic/balance.dart';

String _typeLabel(String t) {
  switch (t) {
    case TrxType.income:
      return 'Masuk';
    case TrxType.expense:
      return 'Keluar';
    case TrxType.transfer:
      return 'Transfer';
    case TrxType.adjustment:
      return 'Penyesuaian';
    case TrxType.savingIn:
      return 'Setor tabungan';
    case TrxType.savingOut:
      return 'Tarik tabungan';
  }
  return t;
}

class ExportData {
  ExportData({
    required this.month,
    required this.trxs,
    required this.totals,
    required this.categories,
    required this.wallets,
    required this.goals,
  });

  final DateTime month;
  final List<Trx> trxs; // urut lama -> baru
  final MonthTotals totals;
  final Map<int, Category> categories;
  final Map<int, Wallet> wallets;
  final Map<int, SavingsGoal> goals;

  String walletName(int? id) => id == null ? '-' : (wallets[id]?.name ?? '-');

  String describe(Trx t) {
    final cat = t.categoryId == null ? null : categories[t.categoryId]?.name;
    final goal = t.savingsId == null ? null : goals[t.savingsId]?.name;
    return [
      if (cat != null) cat,
      if (goal != null) goal,
      if (t.note != null && t.note!.isNotEmpty) t.note!,
    ].join(' - ');
  }

  String walletText(Trx t) {
    if (t.type == TrxType.transfer) {
      return '${walletName(t.walletId)} > ${walletName(t.toWalletId)}';
    }
    return walletName(t.walletId);
  }
}

String _slug(DateTime m) => '${m.year}-${m.month.toString().padLeft(2, '0')}';

Future<void> exportPdf(ExportData d) async {
  final doc = pw.Document();
  final rows = d.trxs
      .map((t) => [
            t.trxNumber ?? '',
            formatDateTime(t.occurredAt),
            _typeLabel(t.type),
            d.walletText(t),
            d.describe(t),
            formatRupiah(t.amount, withSymbol: false),
          ])
      .toList();

  doc.addPage(
    pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(28),
      build: (_) => [
        pw.Text('Laporan Keuangan ${formatMonth(d.month)}',
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        pw.Text('Pemasukan: ${formatRupiah(d.totals.income)}'),
        pw.Text('Pengeluaran: ${formatRupiah(d.totals.expense)}'),
        pw.Text('Selisih: ${formatRupiah(d.totals.net)}',
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 16),
        pw.TableHelper.fromTextArray(
          headers: ['No.', 'Waktu', 'Jenis', 'Dompet', 'Keterangan', 'Jumlah (Rp)'],
          data: rows,
          headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 9),
          cellStyle: const pw.TextStyle(fontSize: 8),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
          cellAlignments: {5: pw.Alignment.centerRight},
        ),
      ],
    ),
  );

  await Printing.sharePdf(
    bytes: await doc.save(),
    filename: 'laporan-${_slug(d.month)}.pdf',
  );
}

Future<void> exportExcel(ExportData d) async {
  final excel = Excel.createExcel();
  final sheetName = 'Transaksi';
  final defaultSheet = excel.getDefaultSheet();
  if (defaultSheet != null && defaultSheet != sheetName) {
    excel.rename(defaultSheet, sheetName);
  }
  final sheet = excel[sheetName];
  sheet.appendRow([
    TextCellValue('No. Transaksi'),
    TextCellValue('Waktu'),
    TextCellValue('Jenis'),
    TextCellValue('Dompet'),
    TextCellValue('Keterangan'),
    TextCellValue('Jumlah'),
  ]);
  for (final t in d.trxs) {
    sheet.appendRow([
      TextCellValue(t.trxNumber ?? ''),
      TextCellValue(formatDateTime(t.occurredAt)),
      TextCellValue(_typeLabel(t.type)),
      TextCellValue(d.walletText(t)),
      TextCellValue(d.describe(t)),
      IntCellValue(t.amount),
    ]);
  }
  sheet.appendRow([TextCellValue('')]);
  sheet.appendRow([TextCellValue('Pemasukan'), IntCellValue(d.totals.income)]);
  sheet.appendRow([TextCellValue('Pengeluaran'), IntCellValue(d.totals.expense)]);
  sheet.appendRow([TextCellValue('Selisih'), IntCellValue(d.totals.net)]);

  final bytes = excel.save();
  if (bytes == null) return;
  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/laporan-${_slug(d.month)}.xlsx');
  await file.writeAsBytes(bytes, flush: true);
  await Share.shareXFiles([XFile(file.path)], text: 'Laporan ${formatMonth(d.month)}');
}

String _csvCell(String s) => '"${s.replaceAll('"', '""')}"';

Future<void> exportCsv(ExportData d) async {
  final b = StringBuffer('No. Transaksi,Waktu,Jenis,Dompet,Keterangan,Jumlah\n');
  for (final t in d.trxs) {
    b.writeln([
      _csvCell(t.trxNumber ?? ''),
      _csvCell(formatDateTime(t.occurredAt)),
      _csvCell(_typeLabel(t.type)),
      _csvCell(d.walletText(t)),
      _csvCell(d.describe(t)),
      t.amount.toString(),
    ].join(','));
  }
  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/laporan-${_slug(d.month)}.csv');
  await file.writeAsString(b.toString(), flush: true);
  await Share.shareXFiles([XFile(file.path)], text: 'Laporan ${formatMonth(d.month)}');
}
