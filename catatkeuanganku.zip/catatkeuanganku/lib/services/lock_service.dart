import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

/// Kunci aplikasi: PIN (hash + salt di penyimpanan aman) dan biometrik.
class LockService extends ChangeNotifier {
  final _storage = const FlutterSecureStorage();
  final _auth = LocalAuthentication();

  bool pinEnabled = false;
  bool biometricEnabled = false;
  bool locked = false;

  int _failures = 0;
  DateTime? _blockedUntil;

  Future<void> load() async {
    pinEnabled = (await _storage.read(key: 'pin_hash')) != null;
    biometricEnabled = (await _storage.read(key: 'bio')) == '1';
    locked = pinEnabled; // terkunci saat aplikasi dibuka
  }

  String _hash(String pin, String salt) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<void> setPin(String pin) async {
    final salt = List.generate(16, (_) => Random.secure().nextInt(256))
        .map((b) => b.toRadixString(16).padLeft(2, '0'))
        .join();
    await _storage.write(key: 'pin_salt', value: salt);
    await _storage.write(key: 'pin_hash', value: _hash(pin, salt));
    pinEnabled = true;
    notifyListeners();
  }

  Future<bool> verifyPin(String pin) async {
    if (_blockedUntil != null && DateTime.now().isBefore(_blockedUntil!)) {
      return false;
    }
    final salt = await _storage.read(key: 'pin_salt');
    final hash = await _storage.read(key: 'pin_hash');
    if (salt == null || hash == null) return false;
    final ok = _hash(pin, salt) == hash;
    if (ok) {
      _failures = 0;
    } else {
      _failures++;
      if (_failures >= 5) {
        _blockedUntil = DateTime.now().add(const Duration(seconds: 30));
        _failures = 0;
      }
    }
    return ok;
  }

  /// Detik tersisa jika terlalu sering salah PIN.
  int get blockedSeconds {
    if (_blockedUntil == null) return 0;
    final s = _blockedUntil!.difference(DateTime.now()).inSeconds;
    return s > 0 ? s : 0;
  }

  Future<void> disablePin() async {
    await _storage.delete(key: 'pin_hash');
    await _storage.delete(key: 'pin_salt');
    await _storage.write(key: 'bio', value: '0');
    pinEnabled = false;
    biometricEnabled = false;
    locked = false;
    notifyListeners();
  }

  Future<bool> biometricAvailable() async {
    try {
      return await _auth.canCheckBiometrics && await _auth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  Future<void> setBiometric(bool on) async {
    await _storage.write(key: 'bio', value: on ? '1' : '0');
    biometricEnabled = on;
    notifyListeners();
  }

  Future<bool> authenticateBiometric() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'Buka CatatKeuanganKu',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: true),
      );
    } catch (_) {
      return false;
    }
  }

  void lock() {
    if (pinEnabled && !locked) {
      locked = true;
      notifyListeners();
    }
  }

  void unlock() {
    locked = false;
    notifyListeners();
  }
}
