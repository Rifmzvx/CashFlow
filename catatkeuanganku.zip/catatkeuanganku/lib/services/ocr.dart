import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

import '../logic/receipt_parser.dart';

/// Baca struk dari file foto (di perangkat, tanpa internet).
Future<ReceiptData> scanReceipt(String imagePath) async {
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  try {
    final result = await recognizer.processImage(InputImage.fromFilePath(imagePath));
    return parseReceipt(result.text);
  } finally {
    await recognizer.close();
  }
}
