import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/format.dart';
import 'data/models.dart';
import 'data/repository.dart';
import 'logic/balance.dart';
import 'services/lock_service.dart';

/// Di-override di main() setelah database terbuka.
final repoProvider = Provider<Repo>((ref) => throw UnimplementedError());
final lockProvider = Provider<LockService>((ref) => throw UnimplementedError());

/// Naikkan angka ini setiap selesai menulis data, semua layar ikut menyegarkan.
final refreshProvider = StateProvider<int>((ref) => 0);
void refreshAll(WidgetRef ref) => ref.read(refreshProvider.notifier).state++;

final walletsProvider = FutureProvider.autoDispose<List<Wallet>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).wallets();
});

final categoriesProvider = FutureProvider.autoDispose<List<Category>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).categories();
});

final goalsProvider = FutureProvider.autoDispose<List<SavingsGoal>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).goals();
});

final liteProvider = FutureProvider.autoDispose<List<TrxLite>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).activeLite();
});

/// Saldo tiap dompet: saldo awal + transaksi aktif.
final walletBalancesProvider = FutureProvider.autoDispose<Map<int, int>>((ref) async {
  final wallets = await ref.watch(walletsProvider.future);
  final lite = await ref.watch(liteProvider.future);
  return {
    for (final w in wallets)
      w.id!: walletBalance(walletId: w.id!, initialBalance: w.initialBalance, trxs: lite),
  };
});

final goalBalancesProvider = FutureProvider.autoDispose<Map<int, int>>((ref) async {
  final goals = await ref.watch(goalsProvider.future);
  final lite = await ref.watch(liteProvider.future);
  return {for (final g in goals) g.id!: savingsBalance(g.id!, lite)};
});

/// Saldo total = semua dompet + semua tabungan.
final totalBalanceProvider = FutureProvider.autoDispose<int>((ref) async {
  final wb = await ref.watch(walletBalancesProvider.future);
  final gb = await ref.watch(goalBalancesProvider.future);
  return wb.values.fold<int>(0, (a, b) => a + b) + gb.values.fold<int>(0, (a, b) => a + b);
});

final monthTotalsProvider =
    FutureProvider.autoDispose.family<MonthTotals, DateTime>((ref, month) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).monthTotals(month);
});

/// 6 bulan terakhir (lama -> baru) untuk grafik beranda.
final monthSeriesProvider = FutureProvider.autoDispose<List<MonthTotals>>((ref) async {
  ref.watch(refreshProvider);
  final repo = ref.watch(repoProvider);
  final now = wibNow();
  final out = <MonthTotals>[];
  for (var i = 5; i >= 0; i--) {
    out.add(await repo.monthTotals(DateTime.utc(now.year, now.month - i, 1)));
  }
  return out;
});

final categoryBreakdownProvider =
    FutureProvider.autoDispose.family<List<CatTotal>, DateTime>((ref, month) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).expenseByCategory(month);
});

final recentTrxProvider = FutureProvider.autoDispose<List<Trx>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).trxList(limit: 5);
});

final trashProvider = FutureProvider.autoDispose<List<Trx>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).trxList(deleted: true, limit: 200);
});

final auditProvider = FutureProvider.autoDispose<List<AuditEntry>>((ref) {
  ref.watch(refreshProvider);
  return ref.watch(repoProvider).audits();
});
