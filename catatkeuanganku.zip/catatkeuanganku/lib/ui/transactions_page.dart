import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/format.dart';
import '../data/models.dart';
import '../data/repository.dart';
import '../logic/balance.dart';
import '../providers.dart';
import 'home_page.dart';
import 'widgets.dart';

class TransactionsPage extends ConsumerStatefulWidget {
  const TransactionsPage({super.key});

  @override
  ConsumerState<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends ConsumerState<TransactionsPage> {
  static const _pageSize = 30;
  final _scroll = ScrollController();
  final _search = TextEditingController();
  TrxFilter _filter = TrxFilter();
  final List<Trx> _items = [];
  bool _loading = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 300) _loadMore();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _reload());
  }

  @override
  void dispose() {
    _scroll.dispose();
    _search.dispose();
    super.dispose();
  }

  Future<void> _reload() async {
    _items.clear();
    _done = false;
    await _loadMore();
  }

  Future<void> _loadMore() async {
    if (_loading || _done) return;
    _loading = true;
    final rows = await ref
        .read(repoProvider)
        .trxList(filter: _filter, limit: _pageSize, offset: _items.length);
    if (!mounted) return;
    setState(() {
      _items.addAll(rows);
      if (rows.length < _pageSize) _done = true;
      _loading = false;
    });
  }

  Future<void> _delete(Trx t) async {
    final repo = ref.read(repoProvider);
    await repo.softDeleteTrx(t.id!);
    refreshAll(ref);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text('${t.trxNumber} dipindah ke tempat sampah'),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'Urungkan',
          onPressed: () async {
            await repo.restoreTrx(t.id!);
            refreshAll(ref);
          },
        ),
      ));
  }

  Future<void> _openFilter() async {
    final lk = ref.read(lookupsProvider).valueOrNull;
    if (lk == null) return;
    final f = _filter.copy();
    final applied = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (c) => StatefulBuilder(
        builder: (c, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Filter transaksi', style: Theme.of(c).textTheme.titleMedium),
                const SizedBox(height: 16),
                DropdownButtonFormField<String?>(
                  value: f.type,
                  decoration: const InputDecoration(labelText: 'Jenis'),
                  items: const [
                    DropdownMenuItem(value: null, child: Text('Semua')),
                    DropdownMenuItem(value: TrxType.income, child: Text('Pemasukan')),
                    DropdownMenuItem(value: TrxType.expense, child: Text('Pengeluaran')),
                    DropdownMenuItem(value: TrxType.transfer, child: Text('Transfer')),
                    DropdownMenuItem(value: TrxType.savingIn, child: Text('Setor tabungan')),
                    DropdownMenuItem(value: TrxType.savingOut, child: Text('Tarik tabungan')),
                    DropdownMenuItem(value: TrxType.adjustment, child: Text('Penyesuaian')),
                  ],
                  onChanged: (v) => setSheet(() => f.type = v),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int?>(
                  value: f.walletId,
                  decoration: const InputDecoration(labelText: 'Dompet'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('Semua')),
                    for (final w in lk.wallets.values)
                      DropdownMenuItem(value: w.id, child: Text(w.name)),
                  ],
                  onChanged: (v) => setSheet(() => f.walletId = v),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<int?>(
                  value: f.categoryId,
                  decoration: const InputDecoration(labelText: 'Kategori'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('Semua')),
                    for (final cat in lk.cats.values)
                      DropdownMenuItem(
                        value: cat.id,
                        child: Text('${cat.name} (${cat.type == 'income' ? 'masuk' : 'keluar'})'),
                      ),
                  ],
                  onChanged: (v) => setSheet(() => f.categoryId = v),
                ),
                const SizedBox(height: 16),
                OutlinedButton.icon(
                  icon: const Icon(Icons.date_range),
                  label: Text(f.from == null
                      ? 'Rentang tanggal: semua'
                      : '${formatDate(f.from!)} - ${formatDate(f.to!.subtract(const Duration(days: 1)))}'),
                  onPressed: () async {
                    final r = await showDateRangePicker(
                      context: c,
                      firstDate: DateTime(2020),
                      lastDate: DateTime(2100),
                    );
                    if (r != null) {
                      setSheet(() {
                        f.from = DateTime.utc(r.start.year, r.start.month, r.start.day);
                        f.to = DateTime.utc(r.end.year, r.end.month, r.end.day)
                            .add(const Duration(days: 1));
                      });
                    }
                  },
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          f
                            ..type = null
                            ..walletId = null
                            ..categoryId = null
                            ..from = null
                            ..to = null;
                          Navigator.pop(c, true);
                        },
                        child: const Text('Reset'),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: FilledButton(
                        onPressed: () => Navigator.pop(c, true),
                        child: const Text('Terapkan'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (applied == true) {
      f.query = _search.text;
      _filter = f;
      await _reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Muat ulang daftar saat ada perubahan data.
    ref.listen<int>(refreshProvider, (_, __) => _reload());
    final lk = ref.watch(lookupsProvider).valueOrNull;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _search,
                  textInputAction: TextInputAction.search,
                  decoration: const InputDecoration(
                    hintText: 'Cari catatan atau nomor transaksi',
                    prefixIcon: Icon(Icons.search),
                    isDense: true,
                  ),
                  onSubmitted: (v) {
                    _filter.query = v;
                    _reload();
                  },
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                onPressed: _openFilter,
                icon: Badge(
                  isLabelVisible: _filter.type != null ||
                      _filter.walletId != null ||
                      _filter.categoryId != null ||
                      _filter.from != null,
                  smallSize: 8,
                  child: const Icon(Icons.filter_list),
                ),
                tooltip: 'Filter',
              ),
            ],
          ),
        ),
        Expanded(
          child: lk == null
              ? const Center(child: CircularProgressIndicator())
              : _items.isEmpty
                  ? EmptyState(
                      icon: Icons.receipt_long_outlined,
                      title: _filter.isActive ? 'Tidak ada hasil' : 'Belum ada transaksi',
                      subtitle: _filter.isActive
                          ? 'Coba ubah kata kunci atau filter.'
                          : 'Tekan tombol + untuk mencatat pemasukan atau pengeluaran.',
                    )
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                      itemCount: _items.length + (_done ? 0 : 1),
                      itemBuilder: (context, i) {
                        if (i >= _items.length) {
                          return const Padding(
                            padding: EdgeInsets.all(16),
                            child: Center(child: CircularProgressIndicator()),
                          );
                        }
                        final t = _items[i];
                        return Dismissible(
                          key: ValueKey('trx-${t.id}'),
                          direction: DismissDirection.endToStart,
                          background: Container(
                            alignment: Alignment.centerRight,
                            padding: const EdgeInsets.only(right: 24),
                            color: Theme.of(context).colorScheme.errorContainer,
                            child: const Icon(Icons.delete_outline),
                          ),
                          onDismissed: (_) {
                            setState(() => _items.removeAt(i));
                            _delete(t);
                          },
                          child: TrxTile(t: t, lk: lk, onTap: () => openTrx(context, t)),
                        );
                      },
                    ),
        ),
      ],
    );
  }
}
