import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/format.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../data/repository.dart';
import '../providers.dart';
import '../services/export.dart';
import 'widgets.dart';

class ReportsPage extends ConsumerStatefulWidget {
  const ReportsPage({super.key});

  @override
  ConsumerState<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends ConsumerState<ReportsPage> {
  DateTime _month = monthStart(wibNow());
  bool _exporting = false;

  void _shift(int delta) =>
      setState(() => _month = DateTime.utc(_month.year, _month.month + delta, 1));

  Future<ExportData> _buildExport() async {
    final repo = ref.read(repoProvider);
    final trxs = await repo.trxList(
      filter: TrxFilter(from: _month, to: nextMonth(_month)),
      ascending: true,
      limit: 100000,
    );
    final totals = await repo.monthTotals(_month);
    final lk = await ref.read(lookupsProvider.future);
    return ExportData(
      month: _month,
      trxs: trxs,
      totals: totals,
      categories: lk.cats,
      wallets: lk.wallets,
      goals: lk.goals,
    );
  }

  Future<void> _export(Future<void> Function(ExportData) fn) async {
    setState(() => _exporting = true);
    try {
      await fn(await _buildExport());
    } catch (e) {
      if (mounted) toast(context, 'Ekspor gagal: $e');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final totals = ref.watch(monthTotalsProvider(_month)).valueOrNull ?? MonthTotals(_month, 0, 0);
    final breakdown = ref.watch(categoryBreakdownProvider(_month)).valueOrNull ?? const <CatTotal>[];
    final lk = ref.watch(lookupsProvider).valueOrNull;
    final wallets = ref.watch(walletsProvider).valueOrNull ?? const <Wallet>[];
    final wb = ref.watch(walletBalancesProvider).valueOrNull ?? const <int, int>{};
    final expenseTotal = breakdown.fold<int>(0, (a, b) => a + b.total);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Laporan', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        Row(
          children: [
            IconButton(onPressed: () => _shift(-1), icon: const Icon(Icons.chevron_left)),
            Expanded(
              child: Text(formatMonth(_month),
                  textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
            ),
            IconButton(onPressed: () => _shift(1), icon: const Icon(Icons.chevron_right)),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(child: _Stat(label: 'Pemasukan', value: totals.income, color: kIncome)),
            const SizedBox(width: 8),
            Expanded(child: _Stat(label: 'Pengeluaran', value: totals.expense, color: kExpense)),
          ],
        ),
        const SizedBox(height: 8),
        AppCard(
          child: Row(
            children: [
              const Expanded(child: Text('Arus kas bersih')),
              Text(
                formatRupiah(totals.net),
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: totals.net >= 0 ? kIncome : kExpense,
                ),
              ),
            ],
          ),
        ),
        const SectionTitle('Pengeluaran per kategori'),
        if (breakdown.isEmpty || lk == null)
          const AppCard(child: Text('Belum ada pengeluaran di bulan ini.'))
        else
          AppCard(
            child: Column(
              children: [
                SizedBox(
                  height: 180,
                  child: PieChart(
                    PieChartData(
                      sectionsSpace: 2,
                      centerSpaceRadius: 44,
                      sections: [
                        for (final b in breakdown)
                          PieChartSectionData(
                            value: b.total.toDouble(),
                            color: Color(lk.cats[b.categoryId]?.color ?? 0xFF78909C),
                            title: '',
                            radius: 36,
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                for (final b in breakdown)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: Color(lk.cats[b.categoryId]?.color ?? 0xFF78909C),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(child: Text(lk.cats[b.categoryId]?.name ?? 'Tanpa kategori')),
                        Text('${((b.total * 100) / expenseTotal).round()}%',
                            style: TextStyle(color: scheme.onSurfaceVariant)),
                        const SizedBox(width: 12),
                        Text(formatRupiah(b.total)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        const SectionTitle('Saldo per dompet'),
        AppCard(
          child: Column(
            children: [
              for (final w in wallets.where((w) => !w.archived))
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(children: [
                    Expanded(child: Text(w.name)),
                    Text(formatRupiah(wb[w.id] ?? 0)),
                  ]),
                ),
              if (wallets.where((w) => !w.archived).isEmpty) const Text('Belum ada dompet.'),
            ],
          ),
        ),
        const SectionTitle('Ekspor laporan bulan ini'),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.tonalIcon(
              onPressed: _exporting ? null : () => _export(exportPdf),
              icon: const Icon(Icons.picture_as_pdf_outlined),
              label: const Text('PDF'),
            ),
            FilledButton.tonalIcon(
              onPressed: _exporting ? null : () => _export(exportExcel),
              icon: const Icon(Icons.table_chart_outlined),
              label: const Text('Excel'),
            ),
            FilledButton.tonalIcon(
              onPressed: _exporting ? null : () => _export(exportCsv),
              icon: const Icon(Icons.description_outlined),
              label: const Text('CSV'),
            ),
          ],
        ),
        const SizedBox(height: 32),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value, required this.color});
  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) => AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(formatRupiah(value),
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: color)),
            ),
          ],
        ),
      );
}
