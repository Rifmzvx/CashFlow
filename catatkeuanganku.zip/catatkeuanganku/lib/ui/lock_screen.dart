import 'package:flutter/material.dart';

import '../services/lock_service.dart';

class LockScreen extends StatefulWidget {
  const LockScreen({super.key, required this.lock});
  final LockService lock;

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _pin = '';
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.lock.biometricEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
    }
  }

  Future<void> _tryBiometric() async {
    final ok = await widget.lock.authenticateBiometric();
    if (ok && mounted) widget.lock.unlock();
  }

  Future<void> _press(String digit) async {
    if (_pin.length >= 6) return;
    setState(() {
      _pin += digit;
      _error = null;
    });
    if (_pin.length == 6) {
      final blocked = widget.lock.blockedSeconds;
      if (blocked > 0) {
        setState(() {
          _pin = '';
          _error = 'Terlalu banyak percobaan. Coba lagi dalam $blocked detik.';
        });
        return;
      }
      final ok = await widget.lock.verifyPin(_pin);
      if (!mounted) return;
      if (ok) {
        widget.lock.unlock();
      } else {
        setState(() {
          _pin = '';
          _error = 'PIN salah';
        });
      }
    }
  }

  void _back() {
    if (_pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Widget _key(String label, {VoidCallback? onTap, IconData? icon}) {
    return SizedBox(
      width: 72,
      height: 72,
      child: TextButton(
        onPressed: onTap,
        style: TextButton.styleFrom(shape: const CircleBorder()),
        child: icon != null
            ? Icon(icon, size: 28)
            : Text(label, style: Theme.of(context).textTheme.headlineMedium),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_outline, size: 48, color: scheme.primary),
                const SizedBox(height: 16),
                Text('Masukkan PIN', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 24),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (var i = 0; i < 6; i++)
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        width: 14,
                        height: 14,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: i < _pin.length ? scheme.primary : scheme.outlineVariant,
                        ),
                      ),
                  ],
                ),
                SizedBox(
                  height: 40,
                  child: Center(
                    child: Text(_error ?? '', style: TextStyle(color: scheme.error)),
                  ),
                ),
                for (final row in const [
                  ['1', '2', '3'],
                  ['4', '5', '6'],
                  ['7', '8', '9'],
                ])
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        for (final d in row)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: _key(d, onTap: () => _press(d)),
                          ),
                      ],
                    ),
                  ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: widget.lock.biometricEnabled
                          ? _key('', icon: Icons.fingerprint, onTap: _tryBiometric)
                          : const SizedBox(width: 72, height: 72),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: _key('0', onTap: () => _press('0')),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: _key('', icon: Icons.backspace_outlined, onTap: _back),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
