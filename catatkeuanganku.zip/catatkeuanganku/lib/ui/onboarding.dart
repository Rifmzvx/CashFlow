import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/format.dart';
import '../core/icons.dart';
import '../data/models.dart';
import '../providers.dart';
import 'widgets.dart';

/// Onboarding singkat: buat dompet pertama dan isi saldo awal.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key, required this.onDone});
  final Future<void> Function() onDone;

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingState();
}

class _OnboardingState extends ConsumerState<OnboardingScreen> {
  final _name = TextEditingController(text: 'Tunai');
  final _balance = TextEditingController();
  String _type = 'tunai';
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _balance.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      toast(context, 'Isi nama dompet');
      return;
    }
    setState(() => _busy = true);
    await ref.read(repoProvider).addWallet(Wallet(
          name: name,
          type: _type,
          icon: kWalletIconByType[_type] ?? 'wallet',
          initialBalance: parseRupiah(_balance.text),
        ));
    refreshAll(ref);
    await widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 24),
            Icon(Icons.account_balance_wallet, size: 56, color: scheme.primary),
            const SizedBox(height: 16),
            Text('Selamat datang di CatatKeuanganKu',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text(
              'Catat uang masuk dan keluar, simpan foto bukti, dan pantau tabungan. '
              'Semua data tersimpan di HP-mu dan jalan tanpa internet.',
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
            const SizedBox(height: 32),
            Text('Langkah 1: buat dompet pertama',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),
            TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Nama dompet'),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _type,
              decoration: const InputDecoration(labelText: 'Jenis'),
              items: [
                for (final e in walletTypeLabels.entries)
                  DropdownMenuItem(value: e.key, child: Text(e.value)),
              ],
              onChanged: (v) => setState(() => _type = v ?? 'tunai'),
            ),
            const SizedBox(height: 16),
            AmountField(controller: _balance, label: 'Saldo awal (boleh kosong)'),
            const SizedBox(height: 32),
            FilledButton(
              onPressed: _busy ? null : _start,
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Mulai mencatat'),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Langkah berikutnya: tekan tombol + untuk mencatat transaksi pertama.',
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
