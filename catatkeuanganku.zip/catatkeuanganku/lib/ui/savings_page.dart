import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/format.dart';
import '../core/icons.dart';
import '../core/photo.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../data/repository.dart';
import '../logic/balance.dart';
import '../providers.dart';
import 'widgets.dart';

/// Seluruh riwayat satu tabungan (lama -> baru).
final savingsHistoryProvider =
    FutureProvider.autoDispose.family<List<Trx>, int>((ref, goalId) {
  ref.watch(refreshProvider);
  return ref
      .watch(repoProvider)
      .trxList(filter: TrxFilter(savingsId: goalId), ascending: true, limit: 5000);
});

class SavingsPage extends ConsumerWidget {
  const SavingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final goals = (ref.watch(goalsProvider).valueOrNull ?? const <SavingsGoal>[])
        .where((g) => !g.archived)
        .toList();
    final gb = ref.watch(goalBalancesProvider).valueOrNull ?? const <int, int>{};
    final totalSaved = goals.fold<int>(0, (a, g) => a + (gb[g.id] ?? 0));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Tabungan', style: Theme.of(context).textTheme.headlineSmall),
                  Text('Total ${formatRupiah(totalSaved)}',
                      style: TextStyle(color: scheme.onSurfaceVariant)),
                ],
              ),
            ),
            FilledButton.tonalIcon(
              onPressed: () => showGoalForm(context, ref),
              icon: const Icon(Icons.add),
              label: const Text('Baru'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (goals.isEmpty)
          SizedBox(
            height: 360,
            child: EmptyState(
              icon: Icons.savings_outlined,
              title: 'Belum ada tabungan',
              subtitle: 'Buat tabungan untuk sekolah, liburan, dana darurat, atau beli HP.',
              actionLabel: 'Buat tabungan',
              onAction: () => showGoalForm(context, ref),
            ),
          )
        else
          for (final g in goals)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: AppCard(
                onTap: () => push(context, SavingsDetailPage(goalId: g.id!)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        IconBadge(icon: iconOf(g.icon), color: g.color),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Text(g.name, style: Theme.of(context).textTheme.titleMedium),
                        ),
                        Text(formatRupiah(gb[g.id] ?? 0),
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                      ],
                    ),
                    if (g.targetAmount > 0) ...[
                      const SizedBox(height: 16),
                      LinearProgressIndicator(
                        value: ((gb[g.id] ?? 0) / g.targetAmount).clamp(0.0, 1.0),
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(4),
                        color: Color(g.color),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${(((gb[g.id] ?? 0) * 100) / g.targetAmount).floor()}% dari ${formatRupiah(g.targetAmount)}',
                        style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
                      ),
                    ],
                  ],
                ),
              ),
            ),
        const SizedBox(height: 80),
      ],
    );
  }
}

class SavingsDetailPage extends ConsumerWidget {
  const SavingsDetailPage({super.key, required this.goalId});
  final int goalId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final goals = ref.watch(goalsProvider).valueOrNull ?? const <SavingsGoal>[];
    final matches = goals.where((g) => g.id == goalId);
    if (matches.isEmpty) {
      return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
    }
    final goal = matches.first;
    final balance = ref.watch(goalBalancesProvider).valueOrNull?[goalId] ?? 0;
    final history = ref.watch(savingsHistoryProvider(goalId)).valueOrNull ?? const <Trx>[];

    final now = wibNow();
    final cutoff = now.subtract(const Duration(days: 30));
    var net30 = 0;
    for (final t in history) {
      if (t.occurredAt.isAfter(cutoff)) {
        net30 += t.type == TrxType.savingIn ? t.amount : -t.amount;
      }
    }
    final eta = goal.targetAmount > 0
        ? estimateGoalDate(
            target: goal.targetAmount,
            current: balance,
            netLast30Days: net30,
            now: now,
          )
        : null;

    // Saldo berjalan untuk tampilan Saldo Awal -> Perubahan -> Saldo Akhir.
    final rows = <({Trx t, int before, int after})>[];
    var running = 0;
    for (final t in history) {
      final delta = t.type == TrxType.savingIn ? t.amount : -t.amount;
      rows.add((t: t, before: running, after: running + delta));
      running += delta;
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(goal.name),
        actions: [
          IconButton(
            tooltip: 'Ubah',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => showGoalForm(context, ref, goal: goal),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AppCard(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  IconBadge(icon: iconOf(goal.icon), color: goal.color, size: 48),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(formatRupiah(balance),
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(fontWeight: FontWeight.bold)),
                  ),
                ]),
                if (goal.targetAmount > 0) ...[
                  const SizedBox(height: 16),
                  LinearProgressIndicator(
                    value: (balance / goal.targetAmount).clamp(0.0, 1.0),
                    minHeight: 10,
                    borderRadius: BorderRadius.circular(5),
                    color: Color(goal.color),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${((balance * 100) / goal.targetAmount).floor()}% dari target ${formatRupiah(goal.targetAmount)}',
                    style: TextStyle(color: scheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    balance >= goal.targetAmount
                        ? 'Target tercapai!'
                        : eta == null
                            ? 'Perkiraan tercapai: belum bisa dihitung (belum ada setoran 30 hari terakhir)'
                            : 'Perkiraan tercapai: ${formatDate(eta)}',
                    style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
                  ),
                  if (goal.deadline != null)
                    Text('Tenggat: ${formatDate(goal.deadline!)}',
                        style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12)),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => showSavingsEntry(context, ref, goal, balance, deposit: true),
                  icon: const Icon(Icons.add),
                  label: const Text('Tambah'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => showSavingsEntry(context, ref, goal, balance, deposit: false),
                  icon: const Icon(Icons.remove),
                  label: const Text('Ambil'),
                ),
              ),
            ],
          ),
          const SectionTitle('Riwayat'),
          if (rows.isEmpty)
            const AppCard(child: Text('Belum ada setoran atau penarikan.'))
          else
            for (final r in rows.reversed)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: AppCard(
                  onTap: () => _showEntry(context, ref, r.t),
                  child: Row(
                    children: [
                      Icon(
                        r.t.type == TrxType.savingIn ? Icons.arrow_circle_down : Icons.arrow_circle_up,
                        color: r.t.type == TrxType.savingIn ? kIncome : kExpense,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              r.t.note?.isNotEmpty == true
                                  ? r.t.note!
                                  : (r.t.type == TrxType.savingIn ? 'Setoran' : 'Penarikan'),
                            ),
                            Text(formatDateTime(r.t.occurredAt),
                                style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant)),
                            const SizedBox(height: 4),
                            Text(
                              '${formatRupiah(r.before)} → ${r.t.type == TrxType.savingIn ? '+' : '-'}${formatRupiah(r.t.amount)} → ${formatRupiah(r.after)}',
                              style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Future<void> _showEntry(BuildContext context, WidgetRef ref, Trx t) async {
    final paths = await ref.read(repoProvider).attachmentPaths(t.id!);
    if (!context.mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${t.type == TrxType.savingIn ? '+' : '-'}${formatRupiah(t.amount)}',
                style: Theme.of(c).textTheme.headlineSmall,
              ),
              Text('${t.trxNumber} · ${formatDateTime(t.occurredAt)}'),
              if (t.note?.isNotEmpty == true) ...[
                const SizedBox(height: 8),
                Text(t.note!),
              ],
              const SizedBox(height: 16),
              if (paths.isEmpty)
                const Text('Tidak ada foto bukti.')
              else
                SizedBox(
                  height: 160,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final p in paths)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.file(File(p), height: 160, fit: BoxFit.cover),
                          ),
                        ),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              TextButton.icon(
                onPressed: () async {
                  Navigator.pop(c);
                  await ref.read(repoProvider).softDeleteTrx(t.id!);
                  refreshAll(ref);
                  if (context.mounted) toast(context, 'Dipindah ke tempat sampah');
                },
                icon: const Icon(Icons.delete_outline),
                label: const Text('Hapus (ke tempat sampah)'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Formulir tabungan baru / ubah tabungan.
Future<void> showGoalForm(BuildContext context, WidgetRef ref, {SavingsGoal? goal}) async {
  final name = TextEditingController(text: goal?.name ?? '');
  final target = TextEditingController(
      text: (goal?.targetAmount ?? 0) > 0 ? formatRupiah(goal!.targetAmount, withSymbol: false) : '');
  var icon = goal?.icon ?? 'savings';
  var color = goal?.color ?? kPalette.first;
  DateTime? deadline = goal?.deadline;
  const goalIcons = ['savings', 'school', 'travel', 'phone', 'emergency', 'home', 'health', 'gift', 'star'];

  final saved = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (c) => StatefulBuilder(
      builder: (c, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(goal == null ? 'Tabungan baru' : 'Ubah tabungan',
                  style: Theme.of(c).textTheme.titleMedium),
              const SizedBox(height: 16),
              TextField(
                controller: name,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(labelText: 'Nama (contoh: Beli HP)'),
              ),
              const SizedBox(height: 16),
              AmountField(controller: target, label: 'Target (kosongkan jika tanpa target)'),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in goalIcons)
                    ChoiceChip(
                      label: Icon(iconOf(k), size: 20),
                      selected: icon == k,
                      onSelected: (_) => setSheet(() => icon = k),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: [
                  for (final p in kPalette)
                    GestureDetector(
                      onTap: () => setSheet(() => color = p),
                      child: CircleAvatar(
                        radius: 14,
                        backgroundColor: Color(p),
                        child: color == p
                            ? const Icon(Icons.check, size: 16, color: Colors.white)
                            : null,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                icon: const Icon(Icons.event),
                label: Text(deadline == null ? 'Tenggat (opsional)' : 'Tenggat: ${formatDate(deadline!)}'),
                onPressed: () async {
                  final d = await showDatePicker(
                    context: c,
                    initialDate: deadline ?? DateTime.now().add(const Duration(days: 90)),
                    firstDate: DateTime(2020),
                    lastDate: DateTime(2100),
                  );
                  if (d != null) setSheet(() => deadline = DateTime.utc(d.year, d.month, d.day));
                },
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Simpan')),
              ),
            ],
          ),
        ),
      ),
    ),
  );

  if (saved != true) return;
  final n = name.text.trim();
  if (n.isEmpty) {
    if (context.mounted) toast(context, 'Isi nama tabungan');
    return;
  }
  final repo = ref.read(repoProvider);
  final g = SavingsGoal(
    id: goal?.id,
    name: n,
    icon: icon,
    color: color,
    targetAmount: parseRupiah(target.text),
    deadline: deadline,
    archived: goal?.archived ?? false,
    createdAt: goal?.createdAt,
  );
  if (goal == null) {
    await repo.addGoal(g);
  } else {
    await repo.updateGoal(g);
  }
  refreshAll(ref);
}

/// Setor (+) atau ambil (-) saldo tabungan, lengkap dengan alasan dan foto bukti.
Future<void> showSavingsEntry(
  BuildContext context,
  WidgetRef ref,
  SavingsGoal goal,
  int balance, {
  required bool deposit,
}) async {
  final amount = TextEditingController();
  final note = TextEditingController();
  final paths = <String>[];
  int? walletId; // null = tanpa dompet (uang baru / tidak dilacak)
  var busy = false;
  final wallets = (ref.read(walletsProvider).valueOrNull ?? const <Wallet>[])
      .where((w) => !w.archived)
      .toList();
  final wb = ref.read(walletBalancesProvider).valueOrNull ?? const <int, int>{};

  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (c) => StatefulBuilder(
      builder: (c, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(deposit ? 'Tambah saldo tabungan' : 'Ambil saldo tabungan',
                  style: Theme.of(c).textTheme.titleMedium),
              Text('${goal.name} · saldo ${formatRupiah(balance)}'),
              const SizedBox(height: 16),
              AmountField(controller: amount, autofocus: true),
              const SizedBox(height: 16),
              TextField(
                controller: note,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(
                  labelText: deposit ? 'Sumber / catatan' : 'Alasan / dipakai untuk apa',
                  hintText: deposit ? 'Uang sisa jajan minggu ini' : 'Beli bakso',
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<int?>(
                value: walletId,
                decoration: InputDecoration(
                  labelText: deposit ? 'Diambil dari dompet' : 'Masuk ke dompet',
                  helperText: 'Pilih "Tidak dilacak" jika uangnya tidak berasal dari/ke dompet di aplikasi',
                  helperMaxLines: 2,
                ),
                items: [
                  const DropdownMenuItem<int?>(value: null, child: Text('Tidak dilacak')),
                  for (final w in wallets)
                    DropdownMenuItem<int?>(
                      value: w.id,
                      child: Text('${w.name} (${formatRupiah(wb[w.id] ?? 0)})'),
                    ),
                ],
                onChanged: (v) => setSheet(() => walletId = v),
              ),
              const SizedBox(height: 16),
              PhotoStrip(
                paths: paths,
                onAdd: (src) async {
                  final p = await pickAndCompress(src);
                  if (p != null) setSheet(() => paths.add(p));
                },
                onRemove: (p) => setSheet(() => paths.remove(p)),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: busy
                    ? null
                    : () async {
                        final value = parseRupiah(amount.text);
                        final type = deposit ? TrxType.savingIn : TrxType.savingOut;
                        final err = validateTrx(
                            type: type, amount: value, walletId: walletId, savingsId: goal.id);
                        if (err != null) {
                          toast(c, err);
                          return;
                        }
                        if (!deposit && value > balance) {
                          toast(c, 'Saldo tabungan tidak cukup (${formatRupiah(balance)})');
                          return;
                        }
                        if (deposit && walletId != null && value > (wb[walletId] ?? 0)) {
                          final ok = await confirmDialog(
                            c,
                            'Saldo dompet tidak cukup dan akan minus. Tetap simpan?',
                            confirmLabel: 'Tetap simpan',
                            title: 'Saldo tidak cukup',
                          );
                          if (!ok) return;
                        }
                        setSheet(() => busy = true);
                        final txt = note.text.trim();
                        await ref.read(repoProvider).addTrx(
                              Trx(
                                type: type,
                                amount: value,
                                walletId: walletId,
                                savingsId: goal.id,
                                note: txt.isEmpty ? null : txt,
                                occurredAt: wibNow(),
                              ),
                              attachments: paths,
                            );
                        refreshAll(ref);
                        final after = deposit ? balance + value : balance - value;
                        final m = deposit ? milestoneCrossed(balance, after, goal.targetAmount) : 0;
                        if (c.mounted) Navigator.pop(c);
                        if (m > 0 && context.mounted) {
                          toast(context,
                              m == 100 ? 'Selamat! Target "${goal.name}" tercapai.' : 'Hebat! $m% target "${goal.name}" tercapai.');
                        }
                      },
                child: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Simpan')),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
