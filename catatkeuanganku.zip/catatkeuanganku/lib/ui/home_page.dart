import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/format.dart';
import '../core/icons.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../logic/balance.dart';
import '../providers.dart';
import 'add_transaction.dart';
import 'savings_page.dart';
import 'widgets.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scheme = Theme.of(context).colorScheme;
    final total = ref.watch(totalBalanceProvider).valueOrNull ?? 0;
    final month = monthStart(wibNow());
    final totals = ref.watch(monthTotalsProvider(month)).valueOrNull ??
        MonthTotals(month, 0, 0);
    final series = ref.watch(monthSeriesProvider).valueOrNull ?? const <MonthTotals>[];
    final goals = ref.watch(goalsProvider).valueOrNull ?? const <SavingsGoal>[];
    final gb = ref.watch(goalBalancesProvider).valueOrNull ?? const <int, int>{};
    final recent = ref.watch(recentTrxProvider).valueOrNull ?? const <Trx>[];
    final lk = ref.watch(lookupsProvider).valueOrNull;

    final activeGoals =
        goals.where((g) => !g.archived && g.targetAmount > 0).take(3).toList();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Halo!', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 16),
        // Saldo total
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: scheme.primary,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Saldo total',
                  style: TextStyle(color: scheme.onPrimary.withAlpha(200))),
              const SizedBox(height: 8),
              Text(
                formatRupiah(total),
                style: Theme.of(context)
                    .textTheme
                    .headlineLarge
                    ?.copyWith(color: scheme.onPrimary, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              Text(formatMonth(month),
                  style: TextStyle(color: scheme.onPrimary.withAlpha(200))),
              const SizedBox(height: 8),
              Row(
                children: [
                  _MiniStat(label: 'Masuk', value: totals.income, color: scheme.onPrimary),
                  _MiniStat(label: 'Keluar', value: totals.expense, color: scheme.onPrimary),
                  _MiniStat(label: 'Sisa', value: totals.net, color: scheme.onPrimary),
                ],
              ),
            ],
          ),
        ),

        // Grafik
        const SectionTitle('6 bulan terakhir'),
        AppCard(
          child: SizedBox(
            height: 180,
            child: series.isEmpty
                ? const SizedBox.shrink()
                : _SeriesChart(series: series),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            _Legend(color: kIncome, label: 'Pemasukan'),
            SizedBox(width: 16),
            _Legend(color: kExpense, label: 'Pengeluaran'),
          ],
        ),

        // Target tabungan
        if (activeGoals.isNotEmpty) ...[
          SectionTitle('Target tabungan'),
          for (final g in activeGoals)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                onTap: () => push(context, SavingsDetailPage(goalId: g.id!)),
                child: Row(
                  children: [
                    IconBadge(icon: iconOf(g.icon), color: g.color),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(g.name),
                          const SizedBox(height: 8),
                          LinearProgressIndicator(
                            value: ((gb[g.id] ?? 0) / g.targetAmount).clamp(0.0, 1.0),
                            minHeight: 8,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${formatRupiah(gb[g.id] ?? 0)} dari ${formatRupiah(g.targetAmount)}',
                            style: TextStyle(fontSize: 12, color: scheme.onSurfaceVariant),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],

        // Transaksi terbaru
        const SectionTitle('Transaksi terbaru'),
        if (recent.isEmpty || lk == null)
          const AppCard(
            child: Text('Belum ada transaksi. Tekan tombol + untuk mencatat yang pertama.'),
          )
        else
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Column(
              children: [
                for (final t in recent)
                  TrxTile(
                    t: t,
                    lk: lk,
                    onTap: () => openTrx(context, t),
                  ),
              ],
            ),
          ),
        const SizedBox(height: 80),
      ],
    );
  }
}

/// Buka layar edit untuk transaksi biasa; jenis lain diubah lewat menu terkait.
void openTrx(BuildContext context, Trx t) {
  if (t.type == TrxType.income || t.type == TrxType.expense || t.type == TrxType.transfer) {
    push(context, AddTransactionScreen(existing: t, initialType: t.type));
  } else if (t.type == TrxType.savingIn || t.type == TrxType.savingOut) {
    if (t.savingsId != null) push(context, SavingsDetailPage(goalId: t.savingsId!));
  } else {
    toast(context, 'Penyesuaian saldo dibuat dari menu Dompet.');
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.label, required this.value, required this.color});
  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) => Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: color.withAlpha(200), fontSize: 12)),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                formatRupiah(value),
                style: TextStyle(color: color, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      );
}

class _Legend extends StatelessWidget {
  const _Legend({required this.color, required this.label});
  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontSize: 12)),
        ],
      );
}

class _SeriesChart extends StatelessWidget {
  const _SeriesChart({required this.series});
  final List<MonthTotals> series;

  @override
  Widget build(BuildContext context) {
    var maxY = 1.0;
    for (final m in series) {
      if (m.income > maxY) maxY = m.income.toDouble();
      if (m.expense > maxY) maxY = m.expense.toDouble();
    }
    return BarChart(
      BarChartData(
        maxY: maxY * 1.15,
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        barTouchData: BarTouchData(
          touchTooltipData: BarTouchTooltipData(
            getTooltipItem: (group, gi, rod, ri) => BarTooltipItem(
              formatRupiah(rod.toY.toInt()),
              const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
        ),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(),
          rightTitles: const AxisTitles(),
          leftTitles: const AxisTitles(),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 28,
              getTitlesWidget: (value, meta) {
                final i = value.toInt();
                if (i < 0 || i >= series.length) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(bulanPendek(series[i].month.month),
                      style: const TextStyle(fontSize: 11)),
                );
              },
            ),
          ),
        ),
        barGroups: [
          for (var i = 0; i < series.length; i++)
            BarChartGroupData(
              x: i,
              barsSpace: 4,
              barRods: [
                BarChartRodData(
                  toY: series[i].income.toDouble(),
                  color: kIncome,
                  width: 8,
                  borderRadius: BorderRadius.circular(3),
                ),
                BarChartRodData(
                  toY: series[i].expense.toDouble(),
                  color: kExpense,
                  width: 8,
                  borderRadius: BorderRadius.circular(3),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
