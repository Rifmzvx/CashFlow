import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../core/format.dart';
import '../core/icons.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../logic/balance.dart';
import '../providers.dart';

void push(BuildContext context, Widget page) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
}

Future<bool> confirmDialog(BuildContext context, String message,
    {String confirmLabel = 'Lanjutkan', String title = 'Konfirmasi'}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(confirmLabel)),
      ],
    ),
  );
  return r ?? false;
}

/// Kartu standar: sudut 16, jarak dalam 16.
class AppCard extends StatelessWidget {
  const AppCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap});
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Material(
      color: scheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
    );
  }
}

class IconBadge extends StatelessWidget {
  const IconBadge({super.key, required this.icon, required this.color, this.size = 40});
  final IconData icon;
  final int color;
  final double size;

  @override
  Widget build(BuildContext context) {
    final c = Color(color);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(color: c.withAlpha(36), shape: BoxShape.circle),
      child: Icon(icon, color: c, size: size * 0.55),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.subtitle,
    this.actionLabel,
    this.onAction,
  });
  final IconData icon;
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: scheme.outline),
            const SizedBox(height: 16),
            Text(title,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(subtitle!,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: scheme.onSurfaceVariant)),
            ],
            if (actionLabel != null) ...[
              const SizedBox(height: 24),
              FilledButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.trailing});
  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(0, 24, 0, 8),
        child: Row(
          children: [
            Expanded(child: Text(text, style: Theme.of(context).textTheme.titleMedium)),
            if (trailing != null) trailing!,
          ],
        ),
      );
}

/// Kumpulan peta id -> objek untuk menampilkan nama dompet/kategori/tabungan.
class Lookups {
  const Lookups(this.cats, this.wallets, this.goals);
  final Map<int, Category> cats;
  final Map<int, Wallet> wallets;
  final Map<int, SavingsGoal> goals;
}

final lookupsProvider = FutureProvider.autoDispose<Lookups>((ref) async {
  final c = await ref.watch(categoriesProvider.future);
  final w = await ref.watch(walletsProvider.future);
  final g = await ref.watch(goalsProvider.future);
  return Lookups(
    {for (final x in c) x.id!: x},
    {for (final x in w) x.id!: x},
    {for (final x in g) x.id!: x},
  );
});

/// Satu baris transaksi.
class TrxTile extends StatelessWidget {
  const TrxTile({super.key, required this.t, required this.lk, this.onTap, this.trailing});
  final Trx t;
  final Lookups lk;
  final VoidCallback? onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final cat = t.categoryId == null ? null : lk.cats[t.categoryId];
    final goal = t.savingsId == null ? null : lk.goals[t.savingsId];
    final wallet = t.walletId == null ? null : lk.wallets[t.walletId];
    final to = t.toWalletId == null ? null : lk.wallets[t.toWalletId];

    IconData icon = Icons.category;
    int color = 0xFF78909C;
    String title = t.note?.isNotEmpty == true ? t.note! : (cat?.name ?? '-');
    String sign = '';
    Color amountColor = scheme.onSurface;

    switch (t.type) {
      case TrxType.income:
        icon = iconOf(cat?.icon);
        color = cat?.color ?? 0xFF2E9E6B;
        sign = '+';
        amountColor = kIncome;
      case TrxType.expense:
        icon = iconOf(cat?.icon);
        color = cat?.color ?? 0xFFD9534F;
        sign = '-';
        amountColor = kExpense;
      case TrxType.transfer:
        icon = Icons.swap_horiz;
        color = 0xFF1E88E5;
        title = 'Transfer ${wallet?.name ?? '?'} > ${to?.name ?? '?'}';
      case TrxType.adjustment:
        icon = Icons.tune;
        color = 0xFF78909C;
        title = 'Penyesuaian saldo';
        sign = t.amount >= 0 ? '+' : '-';
        amountColor = t.amount >= 0 ? kIncome : kExpense;
      case TrxType.savingIn:
        icon = iconOf(goal?.icon);
        color = goal?.color ?? 0xFF00897B;
        title = 'Setor: ${goal?.name ?? 'Tabungan'}';
        sign = '+';
        amountColor = kIncome;
      case TrxType.savingOut:
        icon = iconOf(goal?.icon);
        color = goal?.color ?? 0xFF00897B;
        title = 'Tarik: ${goal?.name ?? 'Tabungan'}';
        sign = '-';
        amountColor = kExpense;
    }

    final where = t.type == TrxType.transfer || wallet == null ? '' : ' · ${wallet.name}';
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
      leading: IconBadge(icon: icon, color: color),
      title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        '${formatDateTime(t.occurredAt)}$where\n${t.trxNumber ?? ''}',
        style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12),
      ),
      isThreeLine: true,
      trailing: trailing ??
          Text(
            '$sign${formatRupiah(t.amount.abs())}',
            style: TextStyle(color: amountColor, fontWeight: FontWeight.w600),
          ),
    );
  }
}

/// Deretan lampiran foto + tombol tambah (kamera/galeri).
class PhotoStrip extends StatelessWidget {
  const PhotoStrip({super.key, required this.paths, required this.onAdd, required this.onRemove});
  final List<String> paths;
  final void Function(ImageSource source) onAdd;
  final void Function(String path) onRemove;

  void _chooseSource(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera),
              title: const Text('Ambil foto'),
              onTap: () {
                Navigator.pop(c);
                onAdd(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Pilih dari galeri'),
              onTap: () {
                Navigator.pop(c);
                onAdd(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return SizedBox(
      height: 88,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          InkWell(
            onTap: () => _chooseSource(context),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              width: 88,
              decoration: BoxDecoration(
                border: Border.all(color: scheme.outline),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.add_a_photo_outlined),
                  SizedBox(height: 4),
                  Text('Foto bukti', style: TextStyle(fontSize: 12)),
                ],
              ),
            ),
          ),
          for (final p in paths)
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Stack(
                children: [
                  GestureDetector(
                    onTap: () => showDialog<void>(
                      context: context,
                      builder: (c) => Dialog(
                        child: InteractiveViewer(child: Image.file(File(p))),
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(File(p),
                          width: 88,
                          height: 88,
                          fit: BoxFit.cover,
                          cacheWidth: 240,
                          errorBuilder: (_, __, ___) => Container(
                                width: 88,
                                height: 88,
                                color: scheme.surfaceContainerHighest,
                                child: const Icon(Icons.broken_image),
                              )),
                    ),
                  ),
                  Positioned(
                    top: 2,
                    right: 2,
                    child: InkWell(
                      onTap: () => onRemove(p),
                      child: const CircleAvatar(
                        radius: 11,
                        backgroundColor: Colors.black54,
                        child: Icon(Icons.close, size: 14, color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Kolom input nominal berformat Rupiah.
class AmountField extends StatelessWidget {
  const AmountField({super.key, required this.controller, this.label = 'Nominal', this.autofocus = false});
  final TextEditingController controller;
  final String label;
  final bool autofocus;

  @override
  Widget build(BuildContext context) => TextField(
        controller: controller,
        autofocus: autofocus,
        keyboardType: TextInputType.number,
        inputFormatters: [RupiahInputFormatter()],
        style: Theme.of(context).textTheme.headlineSmall,
        decoration: InputDecoration(labelText: label, prefixText: 'Rp '),
      );
}
