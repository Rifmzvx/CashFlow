import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../core/format.dart';
import '../core/icons.dart';
import '../core/photo.dart';
import '../data/models.dart';
import '../logic/balance.dart';
import '../providers.dart';
import '../services/ocr.dart';
import 'widgets.dart';

/// Form tambah/ubah pemasukan, pengeluaran, dan transfer.
class AddTransactionScreen extends ConsumerStatefulWidget {
  const AddTransactionScreen({
    super.key,
    this.existing,
    this.initialType = TrxType.expense,
    this.startWithScan = false,
  });

  final Trx? existing;
  final String initialType;
  final bool startWithScan;

  @override
  ConsumerState<AddTransactionScreen> createState() => _AddTrxState();
}

class _AddTrxState extends ConsumerState<AddTransactionScreen> {
  late String _type;
  final _amount = TextEditingController();
  final _note = TextEditingController();
  final _fee = TextEditingController();
  int? _walletId;
  int? _toWalletId;
  int? _categoryId;
  late DateTime _when;
  final List<String> _paths = [];
  bool _busy = false;

  bool get _editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _type = e?.type ?? widget.initialType;
    _when = e?.occurredAt ?? wibNow();
    if (e != null) {
      _amount.text = formatRupiah(e.amount.abs(), withSymbol: false);
      _note.text = e.note ?? '';
      _walletId = e.walletId;
      _toWalletId = e.toWalletId;
      _categoryId = e.categoryId;
      ref.read(repoProvider).attachmentPaths(e.id!).then((p) {
        if (mounted) setState(() => _paths.addAll(p));
      });
    }
    if (widget.startWithScan && e == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _scan());
    }
  }

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    _fee.dispose();
    super.dispose();
  }

  List<Wallet> get _activeWallets =>
      (ref.read(walletsProvider).valueOrNull ?? const <Wallet>[])
          .where((w) => !w.archived || w.id == widget.existing?.walletId || w.id == widget.existing?.toWalletId)
          .toList();

  List<Category> get _typeCategories =>
      (ref.read(categoriesProvider).valueOrNull ?? const <Category>[])
          .where((c) => c.type == _type && (!c.archived || c.id == _categoryId))
          .toList();

  /// Dompet dan kategori default supaya mencatat cukup beberapa ketukan.
  int? get _effWallet => _walletId ?? (_activeWallets.isEmpty ? null : _activeWallets.first.id);
  int? get _effCategory {
    if (_type == TrxType.transfer) return null;
    if (_categoryId != null) return _categoryId;
    final list = _typeCategories;
    if (list.isEmpty) return null;
    final other = list.where((c) => c.name == 'Lainnya');
    return (other.isNotEmpty ? other.first : list.first).id;
  }

  Future<void> _addPhoto(ImageSource source) async {
    final path = await pickAndCompress(source);
    if (path != null && mounted) setState(() => _paths.add(path));
  }

  /// Scan struk: foto -> OCR -> isi nominal, catatan, tanggal. Pengguna tetap bisa koreksi.
  Future<void> _scan() async {
    final path = await pickAndCompress(ImageSource.camera);
    if (path == null || !mounted) return;
    setState(() {
      _paths.add(path);
      _busy = true;
    });
    try {
      final r = await scanReceipt(path);
      if (!mounted) return;
      setState(() {
        if (r.total != null) _amount.text = formatRupiah(r.total!, withSymbol: false);
        if (r.merchant != null && _note.text.isEmpty) _note.text = r.merchant!;
        if (r.date != null) {
          _when = DateTime.utc(r.date!.year, r.date!.month, r.date!.day, _when.hour, _when.minute);
        }
      });
      toast(context,
          r.total == null ? 'Total tidak terbaca, isi manual.' : 'Periksa hasil scan sebelum menyimpan.');
    } catch (_) {
      if (mounted) toast(context, 'Struk tidak bisa dibaca. Foto tetap tersimpan, isi manual.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickDateTime() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime(_when.year, _when.month, _when.day),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: _when.hour, minute: _when.minute),
    );
    if (!mounted) return;
    setState(() => _when = DateTime.utc(d.year, d.month, d.day, t?.hour ?? _when.hour, t?.minute ?? _when.minute));
  }

  Future<void> _save() async {
    final repo = ref.read(repoProvider);
    final amount = parseRupiah(_amount.text);
    final walletId = _effWallet;
    final toId = _type == TrxType.transfer ? _toWalletId : null;
    final categoryId = _effCategory;

    final err = validateTrx(type: _type, amount: amount, walletId: walletId, toWalletId: toId);
    if (err != null) {
      toast(context, err);
      return;
    }
    if (_type != TrxType.transfer && categoryId == null) {
      toast(context, 'Pilih kategori');
      return;
    }

    // Peringatan saldo minus (hanya jika uang keluar dari dompet).
    if (_type != TrxType.income && walletId != null) {
      var current = ref.read(walletBalancesProvider).valueOrNull?[walletId] ?? 0;
      final e = widget.existing;
      if (e != null) current -= walletDelta(e.lite, walletId);
      final fee = _type == TrxType.transfer && !_editing ? parseRupiah(_fee.text) : 0;
      final delta = walletDelta(
            TrxLite(type: _type, amount: amount, walletId: walletId, toWalletId: toId),
            walletId,
          ) -
          fee;
      if (current + delta < 0) {
        final ok = await confirmDialog(
          context,
          'Saldo dompet akan menjadi ${formatRupiah(current + delta)} (minus). Tetap simpan?',
          confirmLabel: 'Tetap simpan',
          title: 'Saldo tidak cukup',
        );
        if (!ok) return;
      }
    }

    setState(() => _busy = true);
    final note = _note.text.trim().isEmpty ? null : _note.text.trim();
    final trx = Trx(
      id: widget.existing?.id,
      type: _type,
      amount: amount,
      walletId: walletId,
      toWalletId: toId,
      categoryId: categoryId,
      note: note,
      occurredAt: _when,
    );

    if (_editing) {
      await repo.updateTrx(trx, attachments: _paths);
    } else {
      await repo.addTrx(trx, attachments: _paths);
      final fee = parseRupiah(_fee.text);
      if (_type == TrxType.transfer && fee > 0) {
        // Biaya admin dicatat sebagai pengeluaran terpisah dari dompet asal.
        final cats = ref.read(categoriesProvider).valueOrNull ?? const <Category>[];
        final bill = cats.where((c) => c.type == 'expense' && c.name == 'Tagihan');
        final any = cats.where((c) => c.type == 'expense');
        final catId = (bill.isNotEmpty ? bill.first : (any.isNotEmpty ? any.first : null))?.id;
        await repo.addTrx(Trx(
          type: TrxType.expense,
          amount: fee,
          walletId: walletId,
          categoryId: catId,
          note: 'Biaya admin transfer',
          occurredAt: _when,
        ));
      }
    }
    refreshAll(ref);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    // Pastikan daftar dompet/kategori sudah dimuat.
    ref.watch(walletsProvider);
    ref.watch(categoriesProvider);
    final balances = ref.watch(walletBalancesProvider).valueOrNull ?? const <int, int>{};
    final wallets = _activeWallets;
    final cats = _typeCategories;
    final isTransfer = _type == TrxType.transfer;

    return Scaffold(
      appBar: AppBar(
        title: Text(_editing ? 'Ubah transaksi' : 'Catat transaksi'),
        actions: [
          if (!_editing)
            IconButton(
              tooltip: 'Scan struk',
              icon: const Icon(Icons.document_scanner_outlined),
              onPressed: _busy ? null : _scan,
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_editing)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Text(widget.existing!.trxNumber ?? '',
                  style: Theme.of(context).textTheme.labelLarge),
            ),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: TrxType.income, label: Text('Masuk'), icon: Icon(Icons.arrow_downward)),
              ButtonSegment(value: TrxType.expense, label: Text('Keluar'), icon: Icon(Icons.arrow_upward)),
              ButtonSegment(value: TrxType.transfer, label: Text('Transfer'), icon: Icon(Icons.swap_horiz)),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() {
              _type = s.first;
              _categoryId = null;
            }),
          ),
          const SizedBox(height: 24),
          AmountField(controller: _amount, autofocus: !_editing && !widget.startWithScan),
          const SizedBox(height: 16),
          DropdownButtonFormField<int>(
            value: _effWallet,
            decoration: InputDecoration(labelText: isTransfer ? 'Dari dompet' : 'Dompet'),
            items: [
              for (final w in wallets)
                DropdownMenuItem(
                  value: w.id,
                  child: Text('${w.name}  (${formatRupiah(balances[w.id] ?? 0)})'),
                ),
            ],
            onChanged: (v) => setState(() => _walletId = v),
          ),
          if (isTransfer) ...[
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _toWalletId,
              decoration: const InputDecoration(labelText: 'Ke dompet'),
              items: [
                for (final w in wallets)
                  DropdownMenuItem(value: w.id, child: Text(w.name)),
              ],
              onChanged: (v) => setState(() => _toWalletId = v),
            ),
            if (!_editing) ...[
              const SizedBox(height: 16),
              TextField(
                controller: _fee,
                keyboardType: TextInputType.number,
                inputFormatters: [RupiahInputFormatter()],
                decoration: const InputDecoration(
                  labelText: 'Biaya admin (opsional)',
                  prefixText: 'Rp ',
                  helperText: 'Dicatat sebagai pengeluaran terpisah',
                ),
              ),
            ],
          ] else ...[
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _effCategory,
              decoration: const InputDecoration(labelText: 'Kategori'),
              items: [
                for (final c in cats)
                  DropdownMenuItem(
                    value: c.id,
                    child: Row(children: [
                      Icon(iconOf(c.icon), size: 18, color: Color(c.color)),
                      const SizedBox(width: 8),
                      Text(c.name),
                    ]),
                  ),
              ],
              onChanged: (v) => setState(() => _categoryId = v),
            ),
          ],
          const SizedBox(height: 16),
          InkWell(
            onTap: _pickDateTime,
            borderRadius: BorderRadius.circular(14),
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'Tanggal & jam (WIB)'),
              child: Row(children: [
                const Icon(Icons.event, size: 18),
                const SizedBox(width: 8),
                Text(formatDateTime(_when)),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _note,
            textCapitalization: TextCapitalization.sentences,
            decoration: const InputDecoration(labelText: 'Catatan'),
          ),
          const SizedBox(height: 16),
          PhotoStrip(
            paths: _paths,
            onAdd: _addPhoto,
            onRemove: (p) => setState(() => _paths.remove(p)),
          ),
          const SizedBox(height: 32),
          FilledButton(
            onPressed: _busy ? null : _save,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: _busy
                  ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Simpan'),
            ),
          ),
        ],
      ),
    );
  }
}
