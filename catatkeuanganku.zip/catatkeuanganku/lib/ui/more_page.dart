import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/format.dart';
import '../core/icons.dart';
import '../data/models.dart';
import '../logic/balance.dart';
import '../providers.dart';
import 'widgets.dart';

/// Tab "Lainnya": pintu masuk ke dompet, kategori, tempat sampah,
/// riwayat perubahan, dan keamanan.
class MorePage extends StatelessWidget {
  const MorePage({super.key});

  @override
  Widget build(BuildContext context) {
    Widget item(IconData icon, String title, String subtitle, Widget page) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: AppCard(
          onTap: () => push(context, page),
          child: Row(
            children: [
              IconBadge(icon: icon, color: kPalette.first),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Lainnya', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 16),
        item(Icons.account_balance_wallet, 'Dompet & Akun',
            'Tunai, bank, e-wallet, rekonsiliasi saldo', const WalletsPage()),
        item(Icons.category, 'Kategori', 'Tambah dan ubah kategori sendiri',
            const CategoriesPage()),
        item(Icons.delete_outline, 'Tempat Sampah',
            'Transaksi terhapus bisa dipulihkan 30 hari', const TrashPage()),
        item(Icons.history, 'Riwayat Perubahan',
            'Catatan siapa mengubah apa dan kapan', const AuditPage()),
        item(Icons.lock_outline, 'Keamanan', 'PIN dan sidik jari',
            const SecurityPage()),
      ],
    );
  }
}

// ======================= DOMPET =======================

class WalletsPage extends ConsumerWidget {
  const WalletsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final wallets = ref.watch(walletsProvider);
    final balances = ref.watch(walletBalancesProvider).valueOrNull ?? const <int, int>{};

    return Scaffold(
      appBar: AppBar(title: const Text('Dompet & Akun')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showWalletForm(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Dompet'),
      ),
      body: wallets.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        data: (list) {
          if (list.isEmpty) {
            return EmptyState(
              icon: Icons.account_balance_wallet_outlined,
              title: 'Belum ada dompet',
              subtitle: 'Buat dompet pertama untuk mulai mencatat.',
              actionLabel: 'Buat dompet',
              onAction: () => showWalletForm(context, ref),
            );
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              for (final w in list)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: AppCard(
                    onTap: () => _walletActions(context, ref, w, balances[w.id!] ?? 0),
                    child: Row(
                      children: [
                        IconBadge(icon: iconOf(w.icon), color: w.color),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(w.archived ? '${w.name} (arsip)' : w.name,
                                  style: Theme.of(context).textTheme.titleSmall),
                              Text(walletTypeLabels[w.type] ?? w.type,
                                  style: TextStyle(
                                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                                    fontSize: 12,
                                  )),
                            ],
                          ),
                        ),
                        Text(formatRupiah(balances[w.id!] ?? 0),
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  void _walletActions(BuildContext context, WidgetRef ref, Wallet w, int balance) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Ubah dompet'),
              onTap: () {
                Navigator.pop(c);
                showWalletForm(context, ref, wallet: w);
              },
            ),
            ListTile(
              leading: const Icon(Icons.tune),
              title: const Text('Cocokkan saldo (rekonsiliasi)'),
              subtitle: const Text('Samakan saldo aplikasi dengan saldo asli'),
              onTap: () {
                Navigator.pop(c);
                _reconcile(context, ref, w, balance);
              },
            ),
            ListTile(
              leading: Icon(w.archived ? Icons.unarchive_outlined : Icons.archive_outlined),
              title: Text(w.archived ? 'Aktifkan kembali' : 'Arsipkan dompet'),
              subtitle: const Text('Riwayat transaksi tetap tersimpan'),
              onTap: () async {
                Navigator.pop(c);
                await ref.read(repoProvider).updateWallet(w.copyWith(archived: !w.archived));
                refreshAll(ref);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _reconcile(BuildContext context, WidgetRef ref, Wallet w, int current) async {
    final ctrl = TextEditingController(text: formatRupiah(current < 0 ? 0 : current, withSymbol: false));
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('Cocokkan ${w.name}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Saldo di aplikasi: ${formatRupiah(current)}'),
            const SizedBox(height: 16),
            AmountField(controller: ctrl, label: 'Saldo asli sekarang'),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true) return;
    final diff = parseRupiah(ctrl.text) - current;
    if (!context.mounted) return;
    if (diff == 0) {
      toast(context, 'Saldo sudah sama, tidak ada selisih');
      return;
    }
    await ref.read(repoProvider).addTrx(Trx(
          type: TrxType.adjustment,
          amount: diff,
          walletId: w.id,
          note: 'Penyesuaian saldo ${w.name}',
          occurredAt: wibNow(),
        ));
    refreshAll(ref);
    if (context.mounted) {
      toast(context, 'Selisih ${formatRupiah(diff)} dicatat sebagai penyesuaian');
    }
  }
}

Future<void> showWalletForm(BuildContext context, WidgetRef ref, {Wallet? wallet}) async {
  final name = TextEditingController(text: wallet?.name ?? '');
  final balance = TextEditingController(
      text: (wallet?.initialBalance ?? 0) != 0
          ? formatRupiah(wallet!.initialBalance, withSymbol: false)
          : '');
  var type = wallet?.type ?? 'tunai';
  var icon = wallet?.icon ?? (kWalletIconByType['tunai'] ?? 'wallet');
  var color = wallet?.color ?? kPalette.first;
  const walletIcons = ['cash', 'bank', 'phone', 'wallet', 'savings', 'home', 'star'];

  final saved = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (c) => StatefulBuilder(
      builder: (c, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(wallet == null ? 'Dompet baru' : 'Ubah dompet',
                  style: Theme.of(c).textTheme.titleMedium),
              const SizedBox(height: 16),
              TextField(
                controller: name,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Nama (contoh: BCA, DANA)'),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: [
                  for (final e in walletTypeLabels.entries)
                    ChoiceChip(
                      label: Text(e.value),
                      selected: type == e.key,
                      onSelected: (_) => setSheet(() {
                        type = e.key;
                        icon = kWalletIconByType[e.key] ?? 'wallet';
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              AmountField(controller: balance, label: 'Saldo awal'),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in walletIcons)
                    ChoiceChip(
                      label: Icon(iconOf(k), size: 20),
                      selected: icon == k,
                      onSelected: (_) => setSheet(() => icon = k),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                children: [
                  for (final p in kPalette)
                    GestureDetector(
                      onTap: () => setSheet(() => color = p),
                      child: CircleAvatar(
                        radius: 14,
                        backgroundColor: Color(p),
                        child: color == p
                            ? const Icon(Icons.check, size: 16, color: Colors.white)
                            : null,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: () => Navigator.pop(c, true),
                child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12), child: Text('Simpan')),
              ),
            ],
          ),
        ),
      ),
    ),
  );

  if (saved != true) return;
  final n = name.text.trim();
  if (n.isEmpty) {
    if (context.mounted) toast(context, 'Isi nama dompet');
    return;
  }
  final repo = ref.read(repoProvider);
  if (wallet == null) {
    await repo.addWallet(Wallet(
      name: n,
      type: type,
      icon: icon,
      color: color,
      initialBalance: parseRupiah(balance.text),
    ));
  } else {
    await repo.updateWallet(wallet.copyWith(
      name: n,
      type: type,
      icon: icon,
      color: color,
      initialBalance: parseRupiah(balance.text),
    ));
  }
  refreshAll(ref);
}

// ======================= KATEGORI =======================

class CategoriesPage extends ConsumerWidget {
  const CategoriesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cats = ref.watch(categoriesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Kategori')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _form(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Kategori'),
      ),
      body: cats.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        data: (list) {
          Widget section(String title, String type) {
            final items = list.where((c) => c.type == type).toList();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SectionTitle(title),
                for (final c in items)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: IconBadge(icon: iconOf(c.icon), color: c.color),
                    title: Text(c.archived ? '${c.name} (arsip)' : c.name),
                    subtitle: c.isDefault ? const Text('Bawaan') : null,
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) async {
                        if (v == 'edit') {
                          _form(context, ref, category: c);
                        } else {
                          await ref.read(repoProvider).updateCategory(Category(
                                id: c.id,
                                name: c.name,
                                type: c.type,
                                icon: c.icon,
                                color: c.color,
                                isDefault: c.isDefault,
                                archived: !c.archived,
                              ));
                          refreshAll(ref);
                        }
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: 'edit', child: Text('Ubah')),
                        PopupMenuItem(
                            value: 'archive',
                            child: Text(c.archived ? 'Aktifkan kembali' : 'Arsipkan')),
                      ],
                    ),
                  ),
              ],
            );
          }

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
            children: [
              section('Pemasukan', 'income'),
              section('Pengeluaran', 'expense'),
            ],
          );
        },
      ),
    );
  }

  Future<void> _form(BuildContext context, WidgetRef ref, {Category? category}) async {
    final name = TextEditingController(text: category?.name ?? '');
    var type = category?.type ?? 'expense';
    var icon = category?.icon ?? 'other';
    var color = category?.color ?? kPalette.last;
    const catIcons = [
      'food', 'transport', 'bill', 'shop', 'fun', 'school', 'health', 'home',
      'gift', 'salary', 'sell', 'allowance', 'star', 'other',
    ];

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (c) => StatefulBuilder(
        builder: (c, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(c).viewInsets.bottom),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(category == null ? 'Kategori baru' : 'Ubah kategori',
                    style: Theme.of(c).textTheme.titleMedium),
                const SizedBox(height: 16),
                TextField(
                  controller: name,
                  textCapitalization: TextCapitalization.sentences,
                  decoration: const InputDecoration(labelText: 'Nama kategori'),
                ),
                const SizedBox(height: 16),
                if (category == null)
                  Wrap(
                    spacing: 8,
                    children: [
                      ChoiceChip(
                        label: const Text('Pemasukan'),
                        selected: type == 'income',
                        onSelected: (_) => setSheet(() => type = 'income'),
                      ),
                      ChoiceChip(
                        label: const Text('Pengeluaran'),
                        selected: type == 'expense',
                        onSelected: (_) => setSheet(() => type = 'expense'),
                      ),
                    ],
                  ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final k in catIcons)
                      ChoiceChip(
                        label: Icon(iconOf(k), size: 20),
                        selected: icon == k,
                        onSelected: (_) => setSheet(() => icon = k),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final p in kPalette)
                      GestureDetector(
                        onTap: () => setSheet(() => color = p),
                        child: CircleAvatar(
                          radius: 14,
                          backgroundColor: Color(p),
                          child: color == p
                              ? const Icon(Icons.check, size: 16, color: Colors.white)
                              : null,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: () => Navigator.pop(c, true),
                  child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12), child: Text('Simpan')),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    if (saved != true) return;
    final n = name.text.trim();
    if (n.isEmpty) {
      if (context.mounted) toast(context, 'Isi nama kategori');
      return;
    }
    final repo = ref.read(repoProvider);
    final c = Category(
      id: category?.id,
      name: n,
      type: type,
      icon: icon,
      color: color,
      isDefault: category?.isDefault ?? false,
      archived: category?.archived ?? false,
    );
    if (category == null) {
      await repo.addCategory(c);
    } else {
      await repo.updateCategory(c);
    }
    refreshAll(ref);
  }
}

// ======================= TEMPAT SAMPAH =======================

class TrashPage extends ConsumerWidget {
  const TrashPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trash = ref.watch(trashProvider);
    final lk = ref.watch(lookupsProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(title: const Text('Tempat Sampah')),
      body: trash.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        data: (list) {
          if (list.isEmpty || lk == null) {
            return const EmptyState(
              icon: Icons.delete_outline,
              title: 'Tempat sampah kosong',
              subtitle: 'Transaksi yang dihapus muncul di sini selama 30 hari.',
            );
          }
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                'Transaksi di sini dihapus permanen otomatis setelah 30 hari.',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 8),
              for (final t in list)
                TrxTile(
                  t: t,
                  lk: lk,
                  trailing: TextButton(
                    onPressed: () async {
                      await ref.read(repoProvider).restoreTrx(t.id!);
                      refreshAll(ref);
                      if (context.mounted) toast(context, 'Transaksi dipulihkan');
                    },
                    child: const Text('Pulihkan'),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

// ======================= RIWAYAT PERUBAHAN =======================

class AuditPage extends ConsumerWidget {
  const AuditPage({super.key});

  static const _entityLabel = {
    'wallet': 'Dompet',
    'category': 'Kategori',
    'savings': 'Tabungan',
    'transaction': 'Transaksi',
    'app': 'Aplikasi',
  };

  static const _actionLabel = {
    'create': 'dibuat',
    'update': 'diubah',
    'delete': 'dihapus',
    'restore': 'dipulihkan',
    'purge': 'dihapus permanen',
    'init': 'disiapkan',
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final audits = ref.watch(auditProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Riwayat Perubahan')),
      body: audits.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        data: (list) {
          if (list.isEmpty) {
            return const EmptyState(
              icon: Icons.history,
              title: 'Belum ada riwayat',
              subtitle: 'Setiap perubahan data akan tercatat di sini.',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final a = list[i];
              final entity = _entityLabel[a.entity] ?? a.entity;
              final action = _actionLabel[a.action] ?? a.action;
              return ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('$entity ${a.entityId ?? ''} $action'.replaceAll('  ', ' ')),
                subtitle: Text(formatDateTime(a.createdAt)),
              );
            },
          );
        },
      ),
    );
  }
}

// ======================= KEAMANAN =======================

class SecurityPage extends ConsumerStatefulWidget {
  const SecurityPage({super.key});

  @override
  ConsumerState<SecurityPage> createState() => _SecurityPageState();
}

class _SecurityPageState extends ConsumerState<SecurityPage> {
  Future<String?> _askPin(String title) {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 6,
          decoration: const InputDecoration(labelText: '6 angka'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('OK')),
        ],
      ),
    );
  }

  Future<void> _setPin() async {
    final lock = ref.read(lockProvider);
    final a = await _askPin('Buat PIN baru');
    if (a == null || !mounted) return;
    if (!RegExp(r'^\d{6}$').hasMatch(a)) {
      toast(context, 'PIN harus 6 angka');
      return;
    }
    final b = await _askPin('Ulangi PIN');
    if (b == null || !mounted) return;
    if (a != b) {
      toast(context, 'PIN tidak sama');
      return;
    }
    await lock.setPin(a);
    if (mounted) toast(context, 'PIN aktif');
  }

  Future<void> _disablePin() async {
    final lock = ref.read(lockProvider);
    final pin = await _askPin('Masukkan PIN untuk menonaktifkan');
    if (pin == null || !mounted) return;
    final ok = await lock.verifyPin(pin);
    if (!mounted) return;
    if (!ok) {
      toast(context, 'PIN salah');
      return;
    }
    await lock.disablePin();
    if (mounted) toast(context, 'PIN dinonaktifkan');
  }

  Future<void> _toggleBio(bool on) async {
    final lock = ref.read(lockProvider);
    if (on) {
      final available = await lock.biometricAvailable();
      if (!mounted) return;
      if (!available) {
        toast(context, 'Sidik jari/Face ID tidak tersedia di HP ini');
        return;
      }
    }
    await lock.setBiometric(on);
  }

  @override
  Widget build(BuildContext context) {
    final lock = ref.watch(lockProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Keamanan')),
      body: ListenableBuilder(
        listenable: lock,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppCard(
              child: Column(
                children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Kunci dengan PIN'),
                    subtitle: const Text('Aplikasi terkunci saat dibuka dan setelah 30 detik di latar belakang'),
                    value: lock.pinEnabled,
                    onChanged: (on) => on ? _setPin() : _disablePin(),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Sidik jari / Face ID'),
                    subtitle: const Text('Buka kunci lebih cepat tanpa mengetik PIN'),
                    value: lock.biometricEnabled,
                    onChanged: lock.pinEnabled ? _toggleBio : null,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Catatan: jika lupa PIN, data tidak bisa dibuka. Simpan PIN di tempat aman.',
              style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
