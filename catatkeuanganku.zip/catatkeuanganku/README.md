# CatatKeuanganKu

Aplikasi Android pencatat keuangan (Flutter, offline-first). Fase 1 (MVP): dompet + transfer,
kategori, transaksi + foto bukti + nomor TRX, edit/hapus/tempat sampah 30 hari, audit log,
tabungan + target, beranda, laporan, ekspor PDF/Excel, PIN/biometrik, kompres foto, scan struk OCR, onboarding.

## Cara dapat APK (tanpa install apa pun di komputer)
1. Buat akun di github.com, lalu buat repositori baru (Private).
2. Unggah seluruh isi folder ini ke repositori (tombol **Add file > Upload files**, termasuk folder `.github`).
3. Buka tab **Actions > Build APK > Run workflow**. Tunggu sekitar 8-12 menit.
4. Setelah hijau, buka run tersebut, bagian **Artifacts**, unduh **CatatKeuanganKu-apk**, ekstrak zip-nya.
5. Kirim `app-release.apk` ke HP, buka, izinkan "Instal dari sumber ini", lalu pasang.

Workflow otomatis membuat folder `android`, menambah izin (kamera, notifikasi, biometrik),
mengatur minSdk 26, menjalankan `flutter analyze` dan `flutter test`, lalu membuat APK.

## Tanda tangan rilis (opsional, wajib untuk Play Store)
```
keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias catat
base64 -w0 release.jks
```
Simpan di GitHub: Settings > Secrets and variables > Actions, dengan nama
`KEYSTORE_BASE64`, `KEY_ALIAS`, `KEY_PASSWORD`, `STORE_PASSWORD`. Simpan file `release.jks` di tempat aman;
bila hilang, aplikasi tidak bisa diperbarui di atas versi lama.

## Jalankan di komputer (opsional)
```
flutter create --platforms=android --org com.namakamu --project-name catatkeuanganku .
python3 tool/patch_android.py .
flutter pub get && flutter test && flutter run
```

## Struktur
- `lib/core` tema, format Rupiah, ikon, foto
- `lib/data` database SQLite (skema berversi), model, repository (transaksi atomik + audit log)
- `lib/logic` perhitungan murni: saldo, validasi, nomor TRX, estimasi target, parser struk
- `lib/services` kunci PIN/biometrik, OCR, ekspor
- `lib/ui` layar
- `test` unit test saldo, transfer, target, format Rupiah, parser struk
