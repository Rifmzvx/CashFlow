"""Menyesuaikan proyek android hasil `flutter create`: izin, minSdk, MainActivity."""
import pathlib, re, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".")
android = root / "android"

# 1) AndroidManifest: izin + nama aplikasi
mf = android / "app/src/main/AndroidManifest.xml"
s = mf.read_text()
perms = """
    <uses-permission android:name="android.permission.CAMERA"/>
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.USE_BIOMETRIC"/>
    <uses-permission android:name="android.permission.USE_FINGERPRINT"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-feature android:name="android.hardware.camera" android:required="false"/>
"""
if "USE_BIOMETRIC" not in s:
    s = re.sub(r"(<manifest[^>]*>)", r"\1" + perms, s, count=1)
s = re.sub(r'android:label="[^"]*"', 'android:label="CatatKeuanganKu"', s, count=1)
mf.write_text(s)

# 2) minSdk 26 (Groovy atau Kotlin DSL)
for name in ("build.gradle", "build.gradle.kts"):
    g = android / "app" / name
    if g.exists():
        t = g.read_text()
        t = re.sub(r"minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)",
                   "minSdk = 26" if name.endswith(".kts") else "minSdkVersion 26", t)
        g.write_text(t)

# 3) local_auth butuh FlutterFragmentActivity
for ma in (android / "app/src/main").rglob("MainActivity.*"):
    t = ma.read_text()
    t = t.replace("FlutterActivity", "FlutterFragmentActivity")
    t = t.replace("io.flutter.embedding.android.FlutterFragmentActivity",
                  "io.flutter.embedding.android.FlutterFragmentActivity")
    ma.write_text(t)
print("android dipatch")

# 4) R8: abaikan class bahasa lain milik ML Kit (OCR kita hanya memakai huruf Latin)
rules = android / "app/proguard-rules.pro"
rules.write_text(
    "-dontwarn com.google.mlkit.vision.text.**\n"
    "-dontwarn com.google.android.gms.internal.mlkit_vision_text_**\n"
    "-dontwarn com.google.errorprone.annotations.**\n"
    "-dontwarn javax.annotation.**\n"
    "-dontwarn org.checkerframework.**\n"
    "-dontwarn com.google.android.play.core.**\n"
    "-dontwarn io.flutter.embedding.engine.deferredcomponents.**\n"
    "-keep class com.tekartik.sqflite.** { *; }\n"
    "-keep class com.it_nomads.fluttersecurestorage.** { *; }\n"
    "-keep class com.google.crypto.tink.** { *; }\n"
    "-keep class androidx.biometric.** { *; }\n"
    "-keep class io.flutter.plugins.localauth.** { *; }\n"
)
for name in ("build.gradle", "build.gradle.kts"):
    g = android / "app" / name
    if not g.exists():
        continue
    t = g.read_text()
    if "proguard-rules.pro" in t:
        continue
    if name.endswith(".kts"):
        line = 'proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")'
    else:
        line = "proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'"
    t, n = re.subn(r"(buildTypes\s*\{\s*(?:getByName\(\"release\"\)|release)\s*\{)",
                   lambda m: m.group(1) + "\n            " + line, t, count=1)
    print(f"{name}: proguard {'dipasang' if n else 'GAGAL dipasang'}")
    g.write_text(t)
